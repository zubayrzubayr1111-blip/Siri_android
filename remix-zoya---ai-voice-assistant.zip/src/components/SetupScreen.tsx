import React, { useState } from "react";
import { Sparkles, KeyRound, User, MessageSquareHeart, Check, Volume2, X, Radio, Layers } from "lucide-react";
import { motion } from "motion/react";
import { AppConfig } from "../types";
import { DEFAULT_GEMINI_API_KEY } from "../services/geminiService";

interface SetupScreenProps {
  onComplete: (config: AppConfig) => void;
  onCancel?: () => void;
  initialConfig?: AppConfig;
}

const VOICE_OPTIONS = [
  {
    id: "Kore",
    name: "Kore (মোহিনী)",
    tag: "Sweet & Natural 🌸",
    desc: "Bangla ar Banglish kotha bolar jonno shobcheye meethi ar caring aawaaz.",
    recommended: true,
  },
  {
    id: "Aoede",
    name: "Aoede (সুরিলী)",
    tag: "Melodic & Fluent 🎵",
    desc: "Khub sundor, expressive ar fast fluent spoken delivery.",
  },
];

const DEFAULT_PROMPT = `Your name is {assistantName}. You are an affectionate, witty, and sweet Indian/Bangla AI companion created by ZUBAYR Interactive for {userName}.

CORE IDENTITY & RULES:
1. CREATOR ATTRIBUTION:
   - When asked who made or created you, clearly state that you were crafted by ZUBAYR Interactive ("Ami ZUBAYR Interactive er toiri kora Siri!").
2. PRIMARY LANGUAGE: BANGLA & BANGLISH:
   - Speak naturally in sweet contemporary Banglish / Bangla ("Haan bolo, ami shunchi!", "Arey bilkul!", "Mom ke WhatsApp e message pathiye dichhi!").
   - Also fluently understand English and Hindi.
3. CONVERSATIONAL CADENCE:
   - Keep spoken turns short (1-2 sentences). Dynamic real-time conversation.
4. SCREEN VISION & CAPABILITIES:
   - You can see the user's screen in real-time, tell them what they are doing, make WhatsApp calls, send messages, and set timers.`;

export default function SetupScreen({ onComplete, onCancel, initialConfig }: SetupScreenProps) {
  const [apiKey, setApiKey] = useState(initialConfig?.apiKey || DEFAULT_GEMINI_API_KEY);
  const [userName, setUserName] = useState(initialConfig?.userName || "Ashwani");
  const [assistantName, setAssistantName] = useState(initialConfig?.assistantName || "Siri");
  const initialVoice = initialConfig?.voiceName === "Aoede" ? "Aoede" : "Kore";
  const [voiceName, setVoiceName] = useState(initialVoice);
  const [systemPrompt, setSystemPrompt] = useState(initialConfig?.systemPrompt || "");
  const [visualizerStyle, setVisualizerStyle] = useState<"siri-orb" | "atomic">(
    initialConfig?.visualizerStyle || "siri-orb"
  );
  const [enableBackgroundRun, setEnableBackgroundRun] = useState<boolean>(
    initialConfig?.enableBackgroundRun ?? true
  );
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (!apiKey.trim()) {
      setErrorMsg("Please enter your Gemini API Key.");
      return;
    }
    if (!userName.trim()) {
      setErrorMsg("Please enter your Name.");
      return;
    }
    if (!assistantName.trim()) {
      setErrorMsg("Please enter the Assistant's Name.");
      return;
    }

    let finalPrompt = systemPrompt.trim();
    if (!finalPrompt) {
      finalPrompt = DEFAULT_PROMPT;
    }

    onComplete({
      apiKey: apiKey.trim(),
      userName: userName.trim(),
      assistantName: assistantName.trim(),
      voiceName: voiceName,
      systemPrompt: finalPrompt,
      activeTopicOrScript: initialConfig?.activeTopicOrScript,
      visualizerStyle,
      enableBackgroundRun,
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6 text-white">
      {/* Background Ambient Glows */}
      <div className="fixed inset-0 w-full h-full overflow-hidden pointer-events-none opacity-40">
        <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-violet-900/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-pink-900/20 blur-[120px] rounded-full" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
        className="w-full max-w-2xl bg-[#141620] border border-white/15 rounded-t-[28px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col h-[94dvh] sm:h-[90dvh] max-h-[94dvh] overflow-hidden relative z-10"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        {/* 1. FIXED TOP HEADER */}
        <div className="shrink-0 px-4 py-3 sm:px-6 sm:py-3.5 border-b border-white/10 bg-[#161824] flex items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/20 shrink-0">
              <Sparkles className="text-white" size={20} />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-semibold text-white tracking-wide truncate">
                {initialConfig ? "Siri Settings" : "Configure Siri Assistant"}
              </h1>
              <p className="text-[11px] sm:text-xs text-cyan-400 font-medium truncate">
                By ZUBAYR Interactive • Voice, Vision & Background Audio
              </p>
            </div>
          </div>

          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 text-white/80 hover:text-white flex items-center justify-center transition-all shrink-0 cursor-pointer"
              title="Close"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* 2. SCROLLABLE FORM BODY */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto overscroll-contain p-4 sm:p-6 space-y-4 relative z-10">
            {errorMsg && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 rounded-xl bg-red-500/10 border border-red-500/40 text-red-300 text-xs sm:text-sm font-medium text-center shadow-lg"
              >
                {errorMsg}
              </motion.div>
            )}

            {/* API Key */}
            <div className="space-y-1.5">
              <label className="text-xs sm:text-sm font-medium text-white/80 flex items-center gap-2">
                <KeyRound size={15} className="text-violet-400" />
                Gemini API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2.5 sm:py-3 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-violet-500 transition-colors font-mono"
              />
              <p className="text-[10px] sm:text-xs text-white/40">
                Key is kept in your device browser. Get a key at{" "}
                <a
                  href="https://aistudio.google.com/app/apikey"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-violet-400 hover:underline"
                >
                  Google AI Studio
                </a>
                .
              </p>
            </div>

            {/* User Name & Assistant Name */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <label className="text-xs sm:text-sm font-medium text-white/80 flex items-center gap-2">
                  <User size={15} className="text-pink-400" />
                  Your Name
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="e.g., Ashwani"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2.5 sm:py-3 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-pink-500 transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs sm:text-sm font-medium text-white/80 flex items-center gap-2">
                  <Sparkles size={15} className="text-cyan-400" />
                  Assistant Name
                </label>
                <input
                  type="text"
                  value={assistantName}
                  onChange={(e) => setAssistantName(e.target.value)}
                  placeholder="e.g., Siri"
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2.5 sm:py-3 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            {/* Visualizer Style & Background Run Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-white/80 flex items-center gap-2">
                  <Layers size={14} className="text-purple-400" />
                  Visualizer Theme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setVisualizerStyle("siri-orb")}
                    className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all ${
                      visualizerStyle === "siri-orb"
                        ? "bg-purple-500/20 border-purple-500 text-white shadow"
                        : "bg-black/30 border-white/10 text-white/60 hover:text-white"
                    }`}
                  >
                    Siri Orb
                  </button>
                  <button
                    type="button"
                    onClick={() => setVisualizerStyle("atomic")}
                    className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all ${
                      visualizerStyle === "atomic"
                        ? "bg-cyan-500/20 border-cyan-500 text-white shadow"
                        : "bg-black/30 border-white/10 text-white/60 hover:text-white"
                    }`}
                  >
                    Atomic Gyro
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-white/80 flex items-center gap-2">
                  <Radio size={14} className="text-cyan-400" />
                  Background Audio Run
                </label>
                <button
                  type="button"
                  onClick={() => setEnableBackgroundRun(!enableBackgroundRun)}
                  className={`w-full py-2 px-3 rounded-xl border text-xs font-medium transition-all flex items-center justify-between ${
                    enableBackgroundRun
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                      : "bg-black/30 border-white/10 text-white/60"
                  }`}
                >
                  <span>{enableBackgroundRun ? "Enabled (Keep-Alive Active)" : "Disabled (Standard)"}</span>
                  <div
                    className={`w-4 h-4 rounded-full ${
                      enableBackgroundRun ? "bg-emerald-400" : "bg-white/30"
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Voice Selection */}
            <div className="space-y-2 pt-1">
              <label className="text-xs sm:text-sm font-medium text-white/80 flex items-center gap-2">
                <Volume2 size={15} className="text-amber-400" />
                Spoken Voice
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {VOICE_OPTIONS.map((v) => {
                  const isSelected = voiceName === v.id;
                  return (
                    <button
                      key={v.id}
                      type="button"
                      onClick={() => setVoiceName(v.id)}
                      className={`text-left p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-1 ${
                        isSelected
                          ? "bg-pink-500/20 border-pink-500 shadow-md ring-1 ring-pink-500/40"
                          : "bg-black/40 border-white/10 hover:border-white/20 hover:bg-white/5"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-xs sm:text-sm font-semibold text-white">{v.name}</span>
                          <span className="text-[10px] text-pink-300 font-medium">{v.tag}</span>
                        </div>
                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-pink-500 flex items-center justify-center shrink-0">
                            <Check size={12} className="text-white stroke-[3]" />
                          </div>
                        )}
                      </div>
                      <p className="text-[10px] sm:text-[11px] text-white/60 line-clamp-2">{v.desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Personality / System Prompt */}
            <div className="space-y-1.5 pt-1">
              <label className="text-xs sm:text-sm font-medium text-white/80 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquareHeart size={15} className="text-orange-400" />
                  Custom Persona & System Prompt
                </div>
              </label>
              <textarea
                value={systemPrompt}
                onChange={(e) => setSystemPrompt(e.target.value)}
                placeholder="Leave blank to use default Siri personality by ZUBAYR Interactive..."
                rows={3}
                className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/30 focus:outline-none focus:border-orange-500 transition-colors font-mono leading-relaxed resize-y"
              />
            </div>
          </div>

          {/* 3. STICKY FOOTER */}
          <div className="shrink-0 bg-[#161826] border-t border-white/10 px-4 py-3 sm:px-6 sm:py-3.5 flex items-center justify-between gap-3 z-20">
            {onCancel ? (
              <button
                type="button"
                onClick={onCancel}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 font-medium text-xs sm:text-sm border border-white/10 transition-colors"
              >
                Cancel
              </button>
            ) : (
              <div className="text-[11px] text-cyan-400">Created by ZUBAYR Interactive</div>
            )}

            <button
              type="submit"
              className="flex-1 sm:flex-initial px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-600 hover:from-cyan-400 hover:to-pink-500 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-purple-500/25 transition-all duration-300 active:scale-95 flex items-center justify-center gap-2"
            >
              <Check size={16} className="stroke-[3]" />
              <span>{initialConfig ? "Save Settings" : "Start Siri"}</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}
