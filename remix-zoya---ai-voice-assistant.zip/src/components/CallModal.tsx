import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Grid,
  Monitor,
  X,
  User,
  ShieldAlert,
  Sparkles,
  PhoneCall,
  Clock,
  Plus,
  MessageSquare,
  Video,
} from "lucide-react";
import { ContactItem, AppState } from "../types";

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
  assistantName?: string;
  initialTarget?: string;
  isWhatsApp?: boolean;
  isMicMuted?: boolean;
  onToggleMicMute?: () => void;
  appState?: AppState;
  onStartScreenShare?: () => void;
  isScreenSharing?: boolean;
}

const DEFAULT_CONTACTS: (ContactItem & { whatsapp: string })[] = [
  { id: "1", name: "Siri (Voice AI)", phone: "Interactive", whatsapp: "Interactive", category: "work", avatarBg: "from-purple-500 to-indigo-600" },
  { id: "2", name: "Mom (Ammu)", phone: "+1 555-0199", whatsapp: "+15550199", category: "family", avatarBg: "from-emerald-500 to-teal-600" },
  { id: "3", name: "Dad (Abbu)", phone: "+1 555-0188", whatsapp: "+15550188", category: "family", avatarBg: "from-blue-500 to-cyan-600" },
  { id: "4", name: "ZUBAYR Interactive", phone: "+1 800-ZUBAYR", whatsapp: "+1800982297", category: "work", avatarBg: "from-cyan-500 to-blue-600" },
  { id: "5", name: "Emergency Services", phone: "911", whatsapp: "911", category: "emergency", avatarBg: "from-red-500 to-orange-600" },
];

export default function CallModal({
  isOpen,
  onClose,
  assistantName = "Siri",
  initialTarget = "Siri",
  isWhatsApp = false,
  isMicMuted = false,
  onToggleMicMute,
  appState = "listening",
  onStartScreenShare,
  isScreenSharing = false,
}: CallModalProps) {
  const [activeTab, setActiveTab] = useState<"call" | "keypad" | "contacts">("call");
  const [targetName, setTargetName] = useState(initialTarget);
  const [isWhatsAppCall, setIsWhatsAppCall] = useState(isWhatsApp || initialTarget.toLowerCase().includes("whatsapp"));
  const [callDuration, setCallDuration] = useState(0);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [keypadInput, setKeypadInput] = useState("");
  const [callConnected, setCallConnected] = useState(true);

  useEffect(() => {
    if (!isOpen) {
      setCallDuration(0);
      return;
    }
    const timer = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  useEffect(() => {
    if (initialTarget) {
      setTargetName(initialTarget);
      setIsWhatsAppCall(isWhatsApp || initialTarget.toLowerCase().includes("whatsapp"));
    }
  }, [initialTarget, isWhatsApp]);

  const formatDuration = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60)
      .toString()
      .padStart(2, "0");
    const secs = (totalSecs % 60).toString().padStart(2, "0");
    return `${mins}:${secs}`;
  };

  const handleDialNumber = (num: string) => {
    if ("vibrate" in navigator) navigator.vibrate(10);
    setKeypadInput((prev) => prev + num);
  };

  const handleCallFromKeypad = () => {
    if (!keypadInput.trim()) return;
    if ("vibrate" in navigator) navigator.vibrate([15, 30]);
    setTargetName(keypadInput.trim());
    setActiveTab("call");
    setCallDuration(0);
  };

  const handleNativeCall = (phone: string) => {
    if ("vibrate" in navigator) navigator.vibrate(20);
    const clean = phone.replace(/[^\d\+]/g, "");
    if (clean) {
      window.open(`tel:${clean}`, "_self");
    }
  };

  const handleWhatsAppDirect = (phone: string) => {
    if ("vibrate" in navigator) navigator.vibrate(20);
    const clean = phone.replace(/[^\d\+]/g, "");
    window.open(`https://api.whatsapp.com/send?phone=${clean}&text=Voice%20call%20requested%20via%20Siri...`, "_blank");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#06080F]/95 backdrop-blur-3xl flex flex-col items-center justify-between text-white p-6 sm:p-8 select-none">
      {/* Background Soft Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-30">
        <div
          className={`absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 blur-[130px] rounded-full ${
            isWhatsAppCall ? "bg-emerald-600/30" : "bg-violet-600/30"
          }`}
        />
      </div>

      {/* Top Header / Mode Switcher */}
      <div className="w-full max-w-sm flex items-center justify-between z-10 pt-2">
        <div className="flex items-center gap-1.5 bg-white/10 rounded-full p-1 border border-white/10">
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(10);
              setActiveTab("call");
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              activeTab === "call" ? "bg-white/20 text-white shadow" : "text-white/60 hover:text-white"
            }`}
          >
            Call
          </button>
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(10);
              setActiveTab("keypad");
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              activeTab === "keypad" ? "bg-white/20 text-white shadow" : "text-white/60 hover:text-white"
            }`}
          >
            Keypad
          </button>
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(10);
              setActiveTab("contacts");
            }}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              activeTab === "contacts" ? "bg-white/20 text-white shadow" : "text-white/60 hover:text-white"
            }`}
          >
            Contacts
          </button>
        </div>

        <button
          onClick={() => {
            if ("vibrate" in navigator) navigator.vibrate(15);
            onClose();
          }}
          className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/70 hover:text-white transition-colors"
          title="Minimize call"
        >
          <X size={16} />
        </button>
      </div>

      {/* Main Content Body */}
      {activeTab === "call" && (
        <div className="flex-1 w-full max-w-sm flex flex-col items-center justify-center z-10 my-4">
          {/* Badge for WhatsApp Call */}
          {isWhatsAppCall && (
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold mb-4"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>WhatsApp Voice Call</span>
            </motion.div>
          )}

          {/* Avatar / Glowing Siri Orb */}
          <div className="relative mb-5">
            <motion.div
              animate={{
                scale: appState === "speaking" ? [1, 1.14, 1] : [1, 1.03, 1],
              }}
              transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
              className={`w-32 h-32 rounded-full p-1 shadow-2xl flex items-center justify-center ${
                isWhatsAppCall
                  ? "bg-gradient-to-tr from-emerald-400 via-teal-500 to-green-600 shadow-emerald-500/40"
                  : "bg-gradient-to-tr from-cyan-500 via-purple-500 to-pink-500 shadow-purple-500/40"
              }`}
            >
              <div className="w-full h-full rounded-full bg-[#0D101A] flex items-center justify-center overflow-hidden">
                <Sparkles
                  size={46}
                  className={isWhatsAppCall ? "text-emerald-300 animate-pulse" : "text-cyan-300 animate-pulse"}
                />
              </div>
            </motion.div>

            {appState === "speaking" && (
              <motion.div
                animate={{ scale: [1, 1.45], opacity: [0.8, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className={`absolute inset-0 rounded-full border-2 ${
                  isWhatsAppCall ? "border-emerald-400" : "border-pink-400"
                }`}
              />
            )}
          </div>

          {/* Caller Details */}
          <h2 className="text-2xl font-bold tracking-tight text-white mb-1 text-center">
            {targetName}
          </h2>
          <div className="flex items-center gap-2 text-sm text-white/60 mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{callConnected ? formatDuration(callDuration) : "Connecting..."}</span>
            <span>• {isWhatsAppCall ? "WhatsApp HD Audio" : "HD Audio"}</span>
          </div>

          <div className="text-[11px] text-cyan-400 font-mono tracking-wider uppercase mb-7">
            Engineered by ZUBAYR Interactive
          </div>

          {/* In-Call Quick Controls */}
          <div className="grid grid-cols-3 gap-5 w-full px-4 mb-4">
            {/* Mute Mic */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  if (onToggleMicMute) onToggleMicMute();
                }}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isMicMuted
                    ? "bg-white text-black"
                    : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                {isMicMuted ? <MicOff size={22} /> : <Mic size={22} />}
              </button>
              <span className="text-xs text-white/70">{isMicMuted ? "Unmute" : "Mute"}</span>
            </div>

            {/* Keypad */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  setActiveTab("keypad");
                }}
                className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all"
              >
                <Grid size={22} />
              </button>
              <span className="text-xs text-white/70">Keypad</span>
            </div>

            {/* Speaker */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  setIsSpeakerOn(!isSpeakerOn);
                }}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isSpeakerOn ? "bg-white text-black" : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                {isSpeakerOn ? <Volume2 size={22} /> : <VolumeX size={22} />}
              </button>
              <span className="text-xs text-white/70">Speaker</span>
            </div>

            {/* Screen Share */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  if (onStartScreenShare) onStartScreenShare();
                }}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                  isScreenSharing
                    ? "bg-cyan-500 text-white shadow-lg shadow-cyan-500/50"
                    : "bg-white/10 hover:bg-white/20 text-white"
                }`}
              >
                <Monitor size={22} />
              </button>
              <span className="text-xs text-white/70">
                {isScreenSharing ? "Sharing" : "Screen"}
              </span>
            </div>

            {/* WhatsApp App launcher */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => handleWhatsAppDirect("+15550199")}
                className="w-14 h-14 rounded-full bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 flex items-center justify-center transition-all"
                title="Open in WhatsApp"
              >
                <MessageSquare size={22} />
              </button>
              <span className="text-xs text-emerald-300">WhatsApp</span>
            </div>

            {/* Contacts */}
            <div className="flex flex-col items-center gap-1.5">
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  setActiveTab("contacts");
                }}
                className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-all"
              >
                <User size={22} />
              </button>
              <span className="text-xs text-white/70">Contacts</span>
            </div>
          </div>
        </div>
      )}

      {/* Keypad Tab */}
      {activeTab === "keypad" && (
        <div className="flex-1 w-full max-w-xs flex flex-col items-center justify-center z-10 my-4">
          <div className="text-2xl font-mono tracking-widest text-center h-12 flex items-center justify-center text-white mb-4">
            {keypadInput || <span className="text-white/30 text-base">Enter phone number...</span>}
          </div>

          <div className="grid grid-cols-3 gap-3.5 w-full mb-5">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"].map((btn) => (
              <button
                key={btn}
                onClick={() => handleDialNumber(btn)}
                className="w-16 h-16 rounded-full bg-white/10 hover:bg-white/25 active:bg-white/40 text-xl font-medium text-white flex items-center justify-center transition-colors mx-auto"
              >
                {btn}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setKeypadInput("")}
              className="text-xs text-white/50 hover:text-white px-3 py-1.5 rounded-lg"
            >
              Clear
            </button>
            <button
              onClick={handleCallFromKeypad}
              disabled={!keypadInput.trim()}
              className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 flex items-center justify-center text-white shadow-lg shadow-emerald-500/30 transition-all"
              title="Voice Call"
            >
              <Phone size={24} />
            </button>
            <button
              onClick={() => handleWhatsAppDirect(keypadInput)}
              disabled={!keypadInput.trim()}
              className="px-3 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-semibold"
            >
              WhatsApp
            </button>
          </div>
        </div>
      )}

      {/* Contacts Tab */}
      {activeTab === "contacts" && (
        <div className="flex-1 w-full max-w-sm flex flex-col z-10 my-4 overflow-hidden">
          <h3 className="text-base font-semibold text-white mb-3 flex items-center justify-between">
            <span>Speed Dial & WhatsApp</span>
            <span className="text-xs text-white/50">One-tap call</span>
          </h3>

          <div className="space-y-2.5 overflow-y-auto max-h-[380px] pr-1">
            {DEFAULT_CONTACTS.map((c) => (
              <div
                key={c.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-full bg-gradient-to-tr ${c.avatarBg} flex items-center justify-center font-bold text-sm text-white shadow`}
                  >
                    {c.name[0]}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white">{c.name}</div>
                    <div className="text-xs text-white/50 font-mono">{c.phone}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* WhatsApp Call button */}
                  <button
                    onClick={() => {
                      if ("vibrate" in navigator) navigator.vibrate(15);
                      setTargetName(`${c.name} (WhatsApp)`);
                      setIsWhatsAppCall(true);
                      setActiveTab("call");
                      setCallDuration(0);
                      handleWhatsAppDirect(c.whatsapp);
                    }}
                    className="p-2.5 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-md transition-colors"
                    title={`WhatsApp Call to ${c.name}`}
                  >
                    <MessageSquare size={14} />
                  </button>

                  {/* Native cellular call button */}
                  {c.phone !== "Interactive" && (
                    <button
                      onClick={() => handleNativeCall(c.phone)}
                      className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                      title="Direct phone dialer"
                    >
                      <PhoneCall size={14} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Red End Call Button (Fixed bottom) */}
      <div className="w-full max-w-sm flex items-center justify-center z-10 pb-4">
        <button
          onClick={() => {
            if ("vibrate" in navigator) navigator.vibrate(30);
            onClose();
          }}
          className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 active:scale-95 text-white flex items-center justify-center shadow-2xl shadow-red-600/50 transition-all cursor-pointer"
          title="End Call"
        >
          <PhoneOff size={28} />
        </button>
      </div>
    </div>
  );
}
