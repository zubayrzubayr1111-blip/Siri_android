import React from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Mic,
  Phone,
  MessageSquare,
  Eye,
  Timer,
  StickyNote,
  X,
  Volume2,
  Sparkles,
  Check,
  RefreshCw,
} from "lucide-react";

interface VoiceCommandsModalProps {
  isOpen: boolean;
  onClose: () => void;
  assistantName?: string;
  onTestCommand?: (cmd: string) => void;
}

const COMMAND_CATEGORIES = [
  {
    title: "Always See Screen & Vision",
    icon: <Eye className="text-cyan-400" size={18} />,
    color: "from-cyan-500/20 to-blue-500/10 border-cyan-500/30",
    commands: [
      { cmd: "Always see screen", desc: "Activates continuous real-time background vision" },
      { cmd: "What am I doing?", desc: "Siri explains what you are doing on screen in Banglish" },
      { cmd: "Ami ekhon ki korchi?", desc: "Asks in Bengali/Banglish what's on screen" },
      { cmd: "Tell me what I'm doing", desc: "Instantly analyzes current app or page" },
    ],
  },
  {
    title: "WhatsApp & Phone Calls",
    icon: <Phone className="text-emerald-400" size={18} />,
    color: "from-emerald-500/20 to-green-500/10 border-emerald-500/30",
    commands: [
      { cmd: "Call mom in WhatsApp", desc: "Starts a direct WhatsApp voice call to Mom" },
      { cmd: "WhatsApp call Dad", desc: "Triggers WhatsApp call to Dad / Abbu" },
      { cmd: "Mom ke WhatsApp e call koro", desc: "Banglish command to WhatsApp call Mom" },
      { cmd: "Call 911 / Police", desc: "Emergency speed dial" },
    ],
  },
  {
    title: "Advanced Messaging",
    icon: <MessageSquare className="text-purple-400" size={18} />,
    color: "from-purple-500/20 to-pink-500/10 border-purple-500/30",
    commands: [
      { cmd: "Message mom I want to go park", desc: "Dispatches 'I want to go park' to Mom via WhatsApp" },
      { cmd: "Text mom I want to go to the park", desc: "Formats & opens WhatsApp/SMS with pre-filled message" },
      { cmd: "Mom ke bolo I am coming home", desc: "Sends Banglish message to Mom" },
      { cmd: "Send WhatsApp message to Dad saying call me", desc: "Sends custom text" },
    ],
  },
  {
    title: "Voice Unstick & Audio Controls",
    icon: <Volume2 className="text-amber-400" size={18} />,
    color: "from-amber-500/20 to-orange-500/10 border-amber-500/30",
    commands: [
      { cmd: "Unstick voice", desc: "Instantly resets audio pipeline if sound freezes" },
      { cmd: "Reset voice", desc: "Clears stuck buffers and resumes listening" },
      { cmd: "Stop talking", desc: "Interrupts Siri immediately and listens to you" },
      { cmd: "Chup koro", desc: "Banglish command to quiet playback" },
    ],
  },
  {
    title: "Timers & Quick Notes",
    icon: <Timer className="text-yellow-400" size={18} />,
    color: "from-yellow-500/20 to-amber-500/10 border-yellow-500/30",
    commands: [
      { cmd: "Set timer for 5 minutes", desc: "Starts a 5m countdown with audible alarm" },
      { cmd: "Take a note buy groceries", desc: "Saves a quick note to scratchpad" },
      { cmd: "Play songs on YouTube", desc: "Launches YouTube music search" },
    ],
  },
];

export default function VoiceCommandsModal({
  isOpen,
  onClose,
  assistantName = "Siri",
  onTestCommand,
}: VoiceCommandsModalProps) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#06080F]/90 backdrop-blur-3xl flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6 select-none"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl bg-[#0F111E] border border-white/15 rounded-t-[32px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden text-white"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        {/* Header */}
        <div className="shrink-0 px-5 py-4 border-b border-white/10 bg-[#141624] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-400 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Mic size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {assistantName} Voice Commands Guide
              </h2>
              <p className="text-xs text-cyan-400">
                Tap any command below to speak or test instantly
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Commands List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {COMMAND_CATEGORIES.map((cat, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-2xl bg-gradient-to-br ${cat.color} border transition-all`}
            >
              <div className="flex items-center gap-2 mb-3">
                {cat.icon}
                <span className="text-xs font-bold uppercase tracking-wider text-white/90">
                  {cat.title}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {cat.commands.map((c, cIdx) => (
                  <button
                    key={cIdx}
                    onClick={() => {
                      if ("vibrate" in navigator) navigator.vibrate(15);
                      if (onTestCommand) onTestCommand(c.cmd);
                      onClose();
                    }}
                    className="text-left p-2.5 rounded-xl bg-black/40 hover:bg-black/60 border border-white/10 hover:border-white/20 transition-all flex flex-col justify-between group active:scale-[0.98]"
                  >
                    <span className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors flex items-center gap-1.5">
                      <span>"{c.cmd}"</span>
                    </span>
                    <span className="text-[10px] text-white/50 mt-1 line-clamp-1">
                      {c.desc}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-[#141624] flex items-center justify-between text-xs text-white/60">
          <span>Major language: Bangla & Banglish</span>
          <span className="text-cyan-400 font-semibold">ZUBAYR Interactive</span>
        </div>
      </motion.div>
    </div>
  );
}
