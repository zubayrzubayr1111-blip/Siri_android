import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MicOff, MessageSquare, RefreshCw, X, ShieldAlert, Sparkles, Check } from 'lucide-react';

interface Props {
  assistantName?: string;
  onClose: () => void;
  onRetry?: () => void;
  onSwitchToText?: () => void;
}

export default function PermissionModal({ assistantName, onClose, onRetry, onSwitchToText }: Props) {
  const companionName = assistantName?.trim() || "Siri";
  const [retrying, setRetrying] = useState(false);
  const [retryResult, setRetryResult] = useState<string | null>(null);

  const handleTestMic = async () => {
    setRetrying(true);
    setRetryResult(null);
    try {
      if (navigator.mediaDevices?.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(t => t.stop());
        setRetryResult("Microphone access granted! Starting voice session...");
        setTimeout(() => {
          onClose();
          if (onRetry) onRetry();
        }, 800);
      } else {
        setRetryResult("Microphone is not supported in this browser context.");
      }
    } catch (err: any) {
      console.warn("Manual microphone retry attempt:", err?.message || err);
      setRetryResult("Still blocked. Please check your browser's lock icon 🔒 or site settings.");
    } finally {
      setRetrying(false);
    }
  };

  const handleTextMode = () => {
    onClose();
    if (onSwitchToText) {
      onSwitchToText();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="w-full max-w-md bg-[#0F111A] border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500" />
        
        <button 
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute top-4 right-4 p-2 rounded-full text-white/50 hover:text-white hover:bg-white/10 transition-colors"
        >
          <X size={18} />
        </button>

        <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-4 shadow-lg shadow-amber-500/5">
          <MicOff size={30} className="text-amber-400" />
        </div>
        
        <h2 className="text-xl sm:text-2xl font-bold text-white mb-2">Microphone Permission</h2>
        <p className="text-white/70 text-xs sm:text-sm mb-5 leading-relaxed">
          Browser microphone access was denied or not permitted. Don't worry — you can still chat with <strong className="text-white">{companionName}</strong> via text with full spoken voice responses!
        </p>

        {retryResult && (
          <div className={`mb-4 px-3.5 py-2.5 rounded-xl text-xs w-full flex items-center gap-2 ${
            retryResult.includes("granted")
              ? "bg-emerald-500/15 border border-emerald-500/30 text-emerald-300"
              : "bg-red-500/15 border border-red-500/30 text-red-300"
          }`}>
            {retryResult.includes("granted") ? <Check size={16} /> : <ShieldAlert size={16} />}
            <span>{retryResult}</span>
          </div>
        )}
        
        {/* Quick Instructions */}
        <div className="bg-white/[0.04] border border-white/10 rounded-2xl p-4 text-left w-full mb-6 text-xs text-white/70 space-y-2">
          <p className="text-white font-medium text-xs flex items-center gap-1.5">
            <Sparkles size={13} className="text-cyan-400" />
            <span>To enable voice speaking:</span>
          </p>
          <ol className="list-decimal pl-4 space-y-1.5 text-white/60">
            <li>Tap the <strong>lock (🔒)</strong> or <strong>site settings (⚙️)</strong> in your browser address bar.</li>
            <li>Change <strong>Microphone</strong> to <strong>Allow</strong>.</li>
            <li>Tap <strong>"Test & Retry Mic"</strong> below without leaving the page.</li>
          </ol>
        </div>
        
        {/* Action Buttons */}
        <div className="flex flex-col w-full gap-2.5">
          {/* Switch to Text mode */}
          <button 
            onClick={handleTextMode}
            className="w-full py-3 px-4 bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-600 hover:from-cyan-400 hover:to-pink-500 text-white font-medium text-sm rounded-xl shadow-lg shadow-purple-600/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <MessageSquare size={16} />
            <span>Chat via Text (No Mic Needed)</span>
          </button>

          {/* Test & Retry Mic */}
          <button 
            onClick={handleTestMic}
            disabled={retrying}
            className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/15 text-white/90 font-medium text-xs rounded-xl border border-white/10 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw size={14} className={retrying ? "animate-spin text-cyan-400" : ""} />
            <span>{retrying ? "Checking microphone..." : "Test & Allow Microphone"}</span>
          </button>

          <button 
            onClick={onClose}
            className="w-full py-2 px-4 text-white/40 hover:text-white/70 text-xs rounded-xl transition-colors"
          >
            Dismiss
          </button>
        </div>
      </motion.div>
    </div>
  );
}
