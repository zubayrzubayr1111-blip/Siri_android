import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Timer, Play, Pause, RotateCcw, X, Bell, BellRing, Sparkles } from "lucide-react";
import { ActiveTimer } from "../types";

interface TimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTimer?: ActiveTimer | null;
  onSetTimer?: (seconds: number, label: string) => void;
  assistantName?: string;
}

export default function TimerModal({
  isOpen,
  onClose,
  activeTimer: externalTimer,
  onSetTimer,
  assistantName = "Siri",
}: TimerModalProps) {
  const [secondsLeft, setSecondsLeft] = useState<number>(() => externalTimer?.remainingSeconds || 300);
  const [isRunning, setIsRunning] = useState<boolean>(() => externalTimer?.isRunning || false);
  const [customInput, setCustomInput] = useState<string>("5");
  const [chimePlayed, setChimePlayed] = useState(false);

  useEffect(() => {
    if (externalTimer) {
      setSecondsLeft(externalTimer.remainingSeconds);
      setIsRunning(externalTimer.isRunning);
    }
  }, [externalTimer]);

  useEffect(() => {
    let interval: any = null;
    if (isRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            playChime();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, secondsLeft]);

  const playChime = () => {
    setChimePlayed(true);
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.8);
    } catch {}
    setTimeout(() => setChimePlayed(false), 5000);
  };

  const handleStartPreset = (mins: number) => {
    const s = mins * 60;
    setSecondsLeft(s);
    setIsRunning(true);
    if (onSetTimer) {
      onSetTimer(s, `${mins} min timer`);
    }
  };

  const handleCustomStart = () => {
    const val = parseFloat(customInput);
    if (isNaN(val) || val <= 0) return;
    const s = Math.round(val * 60);
    setSecondsLeft(s);
    setIsRunning(true);
    if (onSetTimer) {
      onSetTimer(s, `${val} min timer`);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60)
      .toString()
      .padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#141622] border border-white/15 rounded-t-[28px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden text-white"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        <div className="shrink-0 px-4 py-3 sm:px-6 sm:py-3.5 border-b border-white/10 bg-[#161826] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Timer size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-white">Timer & Alarm</h2>
              <p className="text-[11px] text-white/50">{assistantName} countdown controller</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <div className="p-6 flex flex-col items-center">
          {/* Big Digital Countdown */}
          <div
            className={`text-6xl sm:text-7xl font-mono font-light tracking-wider my-4 ${
              chimePlayed ? "text-amber-400 animate-bounce" : "text-white"
            }`}
          >
            {formatTime(secondsLeft)}
          </div>

          {/* Alarm Ring notification banner */}
          {chimePlayed && (
            <div className="flex items-center gap-2 text-amber-300 bg-amber-500/20 border border-amber-500/30 px-3 py-1.5 rounded-full text-xs font-semibold mb-4 animate-pulse">
              <BellRing size={16} />
              <span>Time is up!</span>
            </div>
          )}

          {/* Controls: Play/Pause/Reset */}
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white flex items-center justify-center shadow-lg shadow-amber-500/30 transition-all active:scale-95"
            >
              {isRunning ? <Pause size={24} /> : <Play size={24} className="ml-1" />}
            </button>
            <button
              onClick={() => {
                setIsRunning(false);
                setSecondsLeft(300);
              }}
              className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white/80 flex items-center justify-center transition-colors"
              title="Reset to 5m"
            >
              <RotateCcw size={18} />
            </button>
          </div>

          {/* Presets */}
          <div className="w-full space-y-2">
            <span className="text-xs font-medium text-white/60">Quick Presets</span>
            <div className="grid grid-cols-4 gap-2">
              {[1, 3, 5, 10, 15, 20, 25, 30].map((mins) => (
                <button
                  key={mins}
                  onClick={() => handleStartPreset(mins)}
                  className="py-2 px-1 rounded-xl bg-white/5 hover:bg-white/15 active:bg-amber-500/20 border border-white/10 text-xs font-medium text-center transition-colors"
                >
                  {mins} min
                </button>
              ))}
            </div>
          </div>

          {/* Custom Input */}
          <div className="w-full mt-4 flex items-center gap-2">
            <input
              type="number"
              min="0.1"
              step="0.5"
              value={customInput}
              onChange={(e) => setCustomInput(e.target.value)}
              placeholder="Minutes..."
              className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleCustomStart}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-medium text-white transition-colors"
            >
              Set Mins
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
