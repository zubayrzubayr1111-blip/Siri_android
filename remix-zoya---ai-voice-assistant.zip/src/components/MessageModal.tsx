import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  MessageSquare,
  Send,
  X,
  Smartphone,
  Mail,
  User,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { QuickMessageDraft } from "../types";

interface MessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDraft?: QuickMessageDraft | null;
  assistantName?: string;
  onSendMessage?: (draft: QuickMessageDraft) => void;
}

const QUICK_SNIPPETS = [
  "I want to go park!",
  "Ami park e jete chai",
  "Can you talk right now?",
  "I'm on my way! (Ami aschi)",
  "Please call me back (Call koro please)",
];

const QUICK_CONTACTS = [
  { name: "Mom (Ammu)", phone: "+15550199" },
  { name: "Dad (Abbu)", phone: "+15550188" },
  { name: "ZUBAYR Interactive", phone: "+1800982297" },
];

export default function MessageModal({
  isOpen,
  onClose,
  initialDraft,
  assistantName = "Siri",
  onSendMessage,
}: MessageModalProps) {
  const [platform, setPlatform] = useState<"whatsapp" | "sms" | "email">(
    initialDraft?.platform || "whatsapp"
  );
  const [recipient, setRecipient] = useState(initialDraft?.recipient || "Mom");
  const [message, setMessage] = useState(initialDraft?.text || "");
  const [sentSuccess, setSentSuccess] = useState(false);

  React.useEffect(() => {
    if (initialDraft) {
      if (initialDraft.platform) setPlatform(initialDraft.platform);
      if (initialDraft.recipient) setRecipient(initialDraft.recipient);
      if (initialDraft.text) setMessage(initialDraft.text);
    }
  }, [initialDraft]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    if ("vibrate" in navigator) navigator.vibrate([15, 30]);

    // Check if recipient is a named contact
    let targetPhone = recipient;
    if (recipient.toLowerCase().includes("mom") || recipient.toLowerCase().includes("ammu")) {
      targetPhone = "+15550199";
    } else if (recipient.toLowerCase().includes("dad") || recipient.toLowerCase().includes("abbu")) {
      targetPhone = "+15550188";
    } else if (recipient.toLowerCase().includes("zubayr")) {
      targetPhone = "+1800982297";
    }

    const cleanRecipient = targetPhone.replace(/[^\d\+@\.\w]/g, "");
    const encoded = encodeURIComponent(message.trim());

    if (platform === "whatsapp") {
      const waUrl = cleanRecipient
        ? `https://api.whatsapp.com/send?phone=${cleanRecipient}&text=${encoded}`
        : `https://api.whatsapp.com/send?text=${encoded}`;
      window.open(waUrl, "_blank");
    } else if (platform === "sms") {
      const smsUrl = `sms:${cleanRecipient}?body=${encoded}`;
      window.open(smsUrl, "_self");
    } else if (platform === "email") {
      const mailUrl = `mailto:${cleanRecipient}?subject=Message%20via%20${assistantName}&body=${encoded}`;
      window.open(mailUrl, "_blank");
    }

    if (onSendMessage) {
      onSendMessage({
        platform,
        recipient: recipient.trim(),
        text: message.trim(),
      });
    }

    setSentSuccess(true);
    setTimeout(() => {
      setSentSuccess(false);
      onClose();
    }, 1200);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#06080F]/90 backdrop-blur-3xl flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6 select-none"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#0F111E] border border-white/15 rounded-t-[32px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden relative text-white"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        {/* Header */}
        <div className="shrink-0 px-4 py-3 sm:px-6 sm:py-3.5 border-b border-white/10 bg-[#141624] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <MessageSquare size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-white">
                Send Message with {assistantName}
              </h2>
              <p className="text-[11px] text-white/50">
                Direct WhatsApp, SMS & Email dispatch
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(15);
              onClose();
            }}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSend} className="p-4 sm:p-6 space-y-4 overflow-y-auto">
          {/* Platform Selector Tabs */}
          <div className="grid grid-cols-3 gap-2 p-1 bg-black/40 rounded-2xl border border-white/10">
            <button
              type="button"
              onClick={() => {
                if ("vibrate" in navigator) navigator.vibrate(10);
                setPlatform("whatsapp");
              }}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                platform === "whatsapp"
                  ? "bg-emerald-500 text-white shadow-md shadow-emerald-500/30"
                  : "text-white/60 hover:text-white"
              }`}
            >
              <span>WhatsApp</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if ("vibrate" in navigator) navigator.vibrate(10);
                setPlatform("sms");
              }}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                platform === "sms"
                  ? "bg-blue-500 text-white shadow-md shadow-blue-500/30"
                  : "text-white/60 hover:text-white"
              }`}
            >
              <Smartphone size={14} />
              <span>SMS</span>
            </button>
            <button
              type="button"
              onClick={() => {
                if ("vibrate" in navigator) navigator.vibrate(10);
                setPlatform("email");
              }}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                platform === "email"
                  ? "bg-violet-500 text-white shadow-md shadow-violet-500/30"
                  : "text-white/60 hover:text-white"
              }`}
            >
              <Mail size={14} />
              <span>Email</span>
            </button>
          </div>

          {/* Quick Recipient Select */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-white/80 flex items-center gap-1.5">
                <User size={14} className="text-cyan-400" />
                Recipient
              </label>
              <div className="flex gap-1.5">
                {QUICK_CONTACTS.map((qc) => (
                  <button
                    key={qc.name}
                    type="button"
                    onClick={() => {
                      if ("vibrate" in navigator) navigator.vibrate(10);
                      setRecipient(qc.name);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 hover:bg-white/15 text-cyan-300 border border-white/10"
                  >
                    {qc.name.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>
            <input
              type={platform === "email" ? "email" : "text"}
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="e.g., Mom, Dad, or +15551234567"
              className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          {/* Quick Banglish Snippets */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-medium text-white/50">
              Suggestions (Tap to insert)
            </label>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_SNIPPETS.map((snippet, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if ("vibrate" in navigator) navigator.vibrate(10);
                    setMessage(snippet);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-[11px] text-white/80 transition-colors"
                >
                  {snippet}
                </button>
              ))}
            </div>
          </div>

          {/* Message Textarea */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-white/80 flex items-center justify-between">
              <span>Message Content</span>
              <span className="text-[10px] text-white/40">{message.length} chars</span>
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="e.g. I want to go park, or Ami park e jabo..."
              rows={4}
              className="w-full bg-black/40 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-emerald-500 transition-colors leading-relaxed resize-none"
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={!message.trim() || sentSuccess}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-white font-semibold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-50 cursor-pointer"
          >
            {sentSuccess ? (
              <>
                <CheckCircle2 size={16} className="text-white" />
                <span>Opening {platform.toUpperCase()}...</span>
              </>
            ) : (
              <>
                <Send size={15} />
                <span>Send to {recipient} via {platform.toUpperCase()}</span>
              </>
            )}
          </button>
        </form>
      </motion.div>
    </div>
  );
}
