import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Phone,
  MessageSquare,
  Monitor,
  Timer,
  StickyNote,
  Radio,
  Search,
  MapPin,
  Youtube,
  Music,
  Battery,
  Wifi,
  X,
  Sparkles,
  Settings,
  Shield,
  Layers,
  ChevronRight,
  ExternalLink,
} from "lucide-react";

interface ActionDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  assistantName?: string;
  onOpenCall: () => void;
  onOpenMessage: () => void;
  onToggleScreenShare: () => void;
  isScreenSharing: boolean;
  onOpenTimer: () => void;
  onOpenNotes: () => void;
  onOpenSettings: () => void;
  onOpenVoiceCommands?: () => void;
  onOpenAndroidInstall?: () => void;
  onUnstickVoice?: () => void;
  enableBackgroundRun: boolean;
  onToggleBackgroundRun: (enabled: boolean) => void;
  visualizerStyle: "siri-orb" | "atomic";
  onToggleVisualizerStyle: (style: "siri-orb" | "atomic") => void;
}

export default function ActionDrawer({
  isOpen,
  onClose,
  assistantName = "Siri",
  onOpenCall,
  onOpenMessage,
  onToggleScreenShare,
  isScreenSharing,
  onOpenTimer,
  onOpenNotes,
  onOpenSettings,
  onOpenVoiceCommands,
  onOpenAndroidInstall,
  onUnstickVoice,
  enableBackgroundRun,
  onToggleBackgroundRun,
  visualizerStyle,
  onToggleVisualizerStyle,
}: ActionDrawerProps) {
  const [batteryLevel, setBatteryLevel] = useState<number | null>(null);
  const [isCharging, setIsCharging] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  useEffect(() => {
    // Battery API
    if ("getBattery" in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        setBatteryLevel(Math.round(battery.level * 100));
        setIsCharging(battery.charging);

        battery.addEventListener("levelchange", () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
        battery.addEventListener("chargingchange", () => {
          setIsCharging(battery.charging);
        });
      });
    }

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 40, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl bg-[#121420] border border-white/15 rounded-t-[32px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden text-white"
      >
        {/* Mobile Drag Bar */}
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        {/* Top Bar */}
        <div className="shrink-0 px-5 py-4 border-b border-white/10 bg-[#161826] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 via-purple-600 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/25">
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold tracking-wide text-white">
                  {assistantName} Control Center
                </h2>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Advanced
                </span>
              </div>
              <p className="text-xs text-white/50">
                Crafted & Engineered by ZUBAYR Interactive
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Scrollable Center Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Quick System Status Bar */}
          <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-white/[0.03] border border-white/10 text-xs">
            <div className="flex items-center gap-2 text-white/80">
              <Radio size={14} className="text-cyan-400" />
              <span>Background Run:</span>
              <span className={`font-semibold ${enableBackgroundRun ? "text-emerald-400" : "text-amber-400"}`}>
                {enableBackgroundRun ? "Active" : "Standard"}
              </span>
            </div>
            <div className="flex items-center gap-2 text-white/80 justify-end">
              <Wifi size={14} className={isOnline ? "text-emerald-400" : "text-red-400"} />
              <span>{isOnline ? "Online" : "Offline"}</span>
              {batteryLevel !== null && (
                <>
                  <span className="text-white/30">•</span>
                  <Battery size={14} className="text-cyan-400" />
                  <span>{batteryLevel}%</span>
                </>
              )}
            </div>
          </div>

          {/* Primary Quick Tool Cards */}
          <div>
            <h3 className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-2.5">
              Core Capabilities
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {/* Phone Calls */}
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  onClose();
                  onOpenCall();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-br from-emerald-500/15 to-emerald-700/5 hover:from-emerald-500/25 hover:to-emerald-700/15 border border-emerald-500/30 text-left transition-all active:scale-[0.98] group"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <Phone size={18} />
                </div>
                <div className="text-sm font-semibold text-white">Call Mom / Any</div>
                <div className="text-[11px] text-emerald-300">WhatsApp & Cellular</div>
              </button>

              {/* Messages */}
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  onClose();
                  onOpenMessage();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-br from-cyan-500/15 to-cyan-700/5 hover:from-cyan-500/25 hover:to-cyan-700/15 border border-cyan-500/30 text-left transition-all active:scale-[0.98] group"
              >
                <div className="w-9 h-9 rounded-xl bg-cyan-500 flex items-center justify-center text-white shadow-md shadow-cyan-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <MessageSquare size={18} />
                </div>
                <div className="text-sm font-semibold text-white">Send Message</div>
                <div className="text-[11px] text-cyan-300">WhatsApp, SMS & Email</div>
              </button>

              {/* Screen Share / Always Watch */}
              <button
                onClick={() => {
                  if ("vibrate" in navigator) navigator.vibrate(15);
                  onClose();
                  onToggleScreenShare();
                }}
                className={`p-3.5 rounded-2xl border text-left transition-all active:scale-[0.98] group ${
                  isScreenSharing
                    ? "bg-cyan-500/25 border-cyan-400 shadow-lg shadow-cyan-500/20"
                    : "bg-gradient-to-br from-purple-500/15 to-purple-700/5 hover:from-purple-500/25 border-purple-500/30"
                }`}
              >
                <div className="w-9 h-9 rounded-xl bg-purple-500 flex items-center justify-center text-white shadow-md shadow-purple-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <Monitor size={18} />
                </div>
                <div className="text-sm font-semibold text-white">
                  {isScreenSharing ? "Screen Active" : "See Background"}
                </div>
                <div className="text-[11px] text-purple-300">
                  {isScreenSharing ? "Always Watch: ON" : "AI tells what you're doing"}
                </div>
              </button>

              {/* Timer */}
              <button
                onClick={() => {
                  onClose();
                  onOpenTimer();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-br from-amber-500/15 to-amber-700/5 hover:from-amber-500/25 border border-amber-500/30 text-left transition-all active:scale-[0.98] group"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center text-white shadow-md shadow-amber-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <Timer size={18} />
                </div>
                <div className="text-sm font-semibold text-white">Timer & Alarm</div>
                <div className="text-[11px] text-white/50">Countdown & chimes</div>
              </button>

              {/* Voice Notes */}
              <button
                onClick={() => {
                  onClose();
                  onOpenNotes();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-br from-yellow-500/15 to-yellow-700/5 hover:from-yellow-500/25 border border-yellow-500/30 text-left transition-all active:scale-[0.98] group"
              >
                <div className="w-9 h-9 rounded-xl bg-yellow-500 flex items-center justify-center text-black shadow-md shadow-yellow-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <StickyNote size={18} />
                </div>
                <div className="text-sm font-semibold text-white">Quick Notes</div>
                <div className="text-[11px] text-white/50">Voice memos scratchpad</div>
              </button>

              {/* Settings */}
              <button
                onClick={() => {
                  onClose();
                  onOpenSettings();
                }}
                className="p-3.5 rounded-2xl bg-gradient-to-br from-pink-500/15 to-pink-700/5 hover:from-pink-500/25 border border-pink-500/30 text-left transition-all active:scale-[0.98] group"
              >
                <div className="w-9 h-9 rounded-xl bg-pink-500 flex items-center justify-center text-white shadow-md shadow-pink-500/30 mb-2 group-hover:scale-110 transition-transform">
                  <Settings size={18} />
                </div>
                <div className="text-sm font-semibold text-white">Settings</div>
                <div className="text-[11px] text-white/50">Voice, API & prompt</div>
              </button>
            </div>
          </div>

          {/* Preferences & Quick Toggles */}
          <div className="space-y-3">
            <h3 className="text-xs font-semibold text-white/50 uppercase tracking-wider">
              Experience & Engine
            </h3>

            {/* Visualizer Style Switcher */}
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Layers size={18} className="text-purple-400" />
                <div>
                  <div className="text-xs sm:text-sm font-medium text-white">Visualizer Interface</div>
                  <div className="text-[11px] text-white/50">
                    {visualizerStyle === "siri-orb" ? "Iconic Siri Glowing Orb" : "3D Atomic Gyroscope"}
                  </div>
                </div>
              </div>
              <button
                onClick={() =>
                  onToggleVisualizerStyle(visualizerStyle === "siri-orb" ? "atomic" : "siri-orb")
                }
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition-colors"
              >
                Switch
              </button>
            </div>

            {/* Continuous Background Run Toggle */}
            <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Radio size={18} className="text-cyan-400" />
                <div>
                  <div className="text-xs sm:text-sm font-medium text-white">Continuous Background Run</div>
                  <div className="text-[11px] text-white/50">
                    Keeps mic & audio active when switching apps
                  </div>
                </div>
              </div>
              <button
                onClick={() => onToggleBackgroundRun(!enableBackgroundRun)}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  enableBackgroundRun ? "bg-cyan-500" : "bg-white/20"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full bg-white transition-transform ${
                    enableBackgroundRun ? "translate-x-6" : "translate-x-0.5"
                  }`}
                />
              </button>
            </div>

            {/* Quick Unstick & Commands */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => {
                  onClose();
                  if (onOpenVoiceCommands) onOpenVoiceCommands();
                }}
                className="p-3 rounded-2xl bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 text-left text-xs hover:border-cyan-400 transition-colors"
              >
                <div className="font-semibold text-cyan-300">Voice Commands</div>
                <div className="text-[10px] text-white/50">Full commands guide</div>
              </button>
              <button
                onClick={() => {
                  onClose();
                  if (onOpenAndroidInstall) onOpenAndroidInstall();
                }}
                className="p-3 rounded-2xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/30 text-left text-xs hover:border-emerald-400 transition-colors"
              >
                <div className="font-semibold text-emerald-300">Install Native App</div>
                <div className="text-[10px] text-white/50">Android APK Standalone</div>
              </button>
            </div>
          </div>

          {/* Quick Media & Web Links */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-white/50 uppercase tracking-wider">
              Instant Web Integrations
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => window.open("https://www.youtube.com", "_blank")}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center gap-2 text-white/80 transition-colors"
              >
                <Youtube size={15} className="text-red-400" />
                <span>YouTube</span>
              </button>
              <button
                onClick={() => window.open("https://open.spotify.com", "_blank")}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center gap-2 text-white/80 transition-colors"
              >
                <Music size={15} className="text-green-400" />
                <span>Spotify</span>
              </button>
              <button
                onClick={() => window.open("https://maps.google.com", "_blank")}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center gap-2 text-white/80 transition-colors"
              >
                <MapPin size={15} className="text-blue-400" />
                <span>Google Maps</span>
              </button>
              <button
                onClick={() => window.open("https://www.google.com", "_blank")}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center gap-2 text-white/80 transition-colors"
              >
                <Search size={15} className="text-amber-400" />
                <span>Google Search</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer Attribution */}
        <div className="shrink-0 p-4 border-t border-white/10 bg-[#161826] text-center text-xs text-white/50 flex flex-col items-center gap-1">
          <div className="font-semibold text-white/80 tracking-wide uppercase">
            {assistantName} • AI Voice Assistant
          </div>
          <div className="text-[11px] text-cyan-400/90">
            Proudly Created by ZUBAYR Interactive
          </div>
        </div>
      </motion.div>
    </div>
  );
}
