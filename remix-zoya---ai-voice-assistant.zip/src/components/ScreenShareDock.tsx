import React, { useRef, useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Monitor,
  MonitorOff,
  Eye,
  Maximize2,
  Minimize2,
  PictureInPicture,
  Sparkles,
  Camera,
  X,
  Loader2,
  Radio,
  CheckCircle2,
} from "lucide-react";

interface ScreenShareDockProps {
  stream: MediaStream | null;
  onStop: () => void;
  onAnalyzeFrame?: (imageBase64: string, prompt?: string) => Promise<void> | void;
  assistantName?: string;
  isAlwaysWatching?: boolean;
  onToggleAlwaysWatch?: (active: boolean) => void;
}

export default function ScreenShareDock({
  stream,
  onStop,
  onAnalyzeFrame,
  assistantName = "Siri",
  isAlwaysWatching = false,
  onToggleAlwaysWatch,
}: ScreenShareDockProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isMinimized, setIsMinimized] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastAnalysisNote, setLastAnalysisNote] = useState<string | null>(null);
  const [alwaysWatchLocal, setAlwaysWatchLocal] = useState(isAlwaysWatching);

  useEffect(() => {
    setAlwaysWatchLocal(isAlwaysWatching);
  }, [isAlwaysWatching]);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  // Listen to user ending screen share from native browser bar
  useEffect(() => {
    if (!stream) return;
    const track = stream.getVideoTracks()[0];
    if (track) {
      const handleEnded = () => {
        onStop();
      };
      track.addEventListener("ended", handleEnded);
      return () => {
        track.removeEventListener("ended", handleEnded);
      };
    }
  }, [stream, onStop]);

  // Capture current video frame as base64 JPEG
  const captureFrame = useCallback((): string | null => {
    if (!videoRef.current) return null;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return null;

    const canvas = document.createElement("canvas");
    const maxDim = 960;
    let width = video.videoWidth;
    let height = video.videoHeight;
    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, width, height);
    return canvas.toDataURL("image/jpeg", 0.8);
  }, []);

  const handleAnalyzeClick = async (customPrompt?: string) => {
    if (isAnalyzing) return;
    const frame = captureFrame();
    if (!frame) return;

    if ("vibrate" in navigator) navigator.vibrate(15);
    setIsAnalyzing(true);
    setLastAnalysisNote("Siri dekhche tumi ki korcho...");
    try {
      if (onAnalyzeFrame) {
        await onAnalyzeFrame(
          frame,
          customPrompt || "What is the user doing on their screen right now? Explain concisely in 1 sweet sentence in Banglish."
        );
      }
      setLastAnalysisNote("Siri screen dekhe bujheche!");
      setTimeout(() => setLastAnalysisNote(null), 3500);
    } catch (e) {
      console.error("Frame analysis failed:", e);
      setLastAnalysisNote("Failed to analyze screen frame.");
      setTimeout(() => setLastAnalysisNote(null), 3000);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Continuous Auto Watcher Timer: triggers frame check every 6s when AlwaysWatch is active
  useEffect(() => {
    if (!alwaysWatchLocal || !stream) return;

    const interval = setInterval(() => {
      if (!isAnalyzing) {
        const frame = captureFrame();
        if (frame && onAnalyzeFrame) {
          onAnalyzeFrame(
            frame,
            "The user is doing something on their screen. In 1 short sweet sentence in Banglish, tell the user what they are currently doing."
          );
        }
      }
    }, 7000);

    return () => clearInterval(interval);
  }, [alwaysWatchLocal, stream, isAnalyzing, captureFrame, onAnalyzeFrame]);

  const toggleAlwaysWatch = () => {
    if ("vibrate" in navigator) navigator.vibrate([15, 30]);
    const nextVal = !alwaysWatchLocal;
    setAlwaysWatchLocal(nextVal);
    if (onToggleAlwaysWatch) {
      onToggleAlwaysWatch(nextVal);
    }
  };

  const handlePiP = async () => {
    if (videoRef.current && document.pictureInPictureEnabled) {
      try {
        if (document.pictureInPictureElement) {
          await document.exitPictureInPicture();
        } else {
          await videoRef.current.requestPictureInPicture();
        }
      } catch (err) {
        console.warn("PiP error:", err);
      }
    }
  };

  if (!stream) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 20, scale: 0.95 }}
      className={`fixed z-40 transition-all duration-300 shadow-2xl rounded-3xl bg-[#0B0D16]/95 border border-cyan-500/40 backdrop-blur-2xl overflow-hidden ${
        isMinimized
          ? "bottom-24 right-4 sm:right-6 w-60 sm:w-64 p-3"
          : "bottom-24 right-4 sm:right-6 w-[90vw] max-w-sm sm:max-w-md p-3.5"
      }`}
    >
      {/* Top Header Bar */}
      <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-white/10">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping shrink-0" />
          <span className="text-xs font-semibold text-cyan-300 truncate">
            {alwaysWatchLocal ? "Always Watching Screen" : "Screen Share Active"}
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Always Watch Toggle */}
          <button
            onClick={toggleAlwaysWatch}
            className={`px-2 py-1 rounded-lg text-[10px] font-semibold flex items-center gap-1 transition-all ${
              alwaysWatchLocal
                ? "bg-emerald-500/25 text-emerald-300 border border-emerald-500/50"
                : "bg-white/5 text-white/60 hover:text-white"
            }`}
            title="Auto-detect & tell me what I am doing"
          >
            <Eye size={12} className={alwaysWatchLocal ? "text-emerald-300" : ""} />
            <span>{alwaysWatchLocal ? "Always Watch: ON" : "Auto Watch"}</span>
          </button>

          {/* PiP Button */}
          {document.pictureInPictureEnabled && (
            <button
              onClick={handlePiP}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-colors"
              title="Pop out Picture-in-Picture"
            >
              <PictureInPicture size={14} />
            </button>
          )}

          {/* Minimize / Expand */}
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-colors"
            title={isMinimized ? "Expand view" : "Minimize dock"}
          >
            {isMinimized ? <Maximize2 size={14} /> : <Minimize2 size={14} />}
          </button>

          {/* Stop Sharing */}
          <button
            onClick={onStop}
            className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-colors"
            title="Stop Screen Share"
          >
            <MonitorOff size={14} />
          </button>
        </div>
      </div>

      {/* Video Preview */}
      <div className="relative rounded-2xl overflow-hidden bg-black/60 border border-white/10 aspect-video mb-3 flex items-center justify-center">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-full h-full object-contain"
        />

        {/* Live Indicator overlay */}
        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/75 border border-cyan-500/30 backdrop-blur-md flex items-center gap-1.5 text-[10px] font-mono text-cyan-300">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span>{alwaysWatchLocal ? "LIVE VISION: ON" : "SCREEN LIVE"}</span>
        </div>

        <div className="absolute bottom-2 right-2 text-[9px] text-white/50 font-mono tracking-wider bg-black/60 px-1.5 py-0.5 rounded">
          ZUBAYR Interactive
        </div>
      </div>

      {/* Controls & Quick Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => handleAnalyzeClick()}
          disabled={isAnalyzing}
          className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 active:scale-95 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
        >
          {isAnalyzing ? (
            <>
              <Loader2 size={14} className="animate-spin text-white" />
              <span>Dekhchi...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} className="text-cyan-200" />
              <span>Tell Me What I'm Doing</span>
            </>
          )}
        </button>

        <button
          onClick={onStop}
          className="py-2 px-3 rounded-xl bg-white/5 hover:bg-red-500/20 text-white/70 hover:text-red-300 border border-white/10 text-xs font-medium transition-colors"
          title="Disconnect stream"
        >
          Stop
        </button>
      </div>

      {/* Status toast message */}
      <AnimatePresence>
        {lastAnalysisNote && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2 text-center text-[11px] text-cyan-300 font-medium py-1 px-2 rounded-lg bg-cyan-500/10 border border-cyan-500/30"
          >
            {lastAnalysisNote}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
