import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Download, Smartphone, CheckCircle2, ShieldCheck, X, Sparkles, ExternalLink } from "lucide-react";

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInstall: () => Promise<boolean>;
  isInstallable: boolean;
  isInstalled: boolean;
  assistantName?: string;
}

export default function AndroidInstallModal({
  isOpen,
  onClose,
  onInstall,
  isInstallable,
  isInstalled,
  assistantName = "Siri",
}: AndroidInstallModalProps) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-[#06080F]/90 backdrop-blur-3xl flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6 select-none"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#0F111E] border border-white/15 rounded-t-[32px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden text-white"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        {/* Header */}
        <div className="shrink-0 px-5 py-4 border-b border-white/10 bg-[#141624] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-400 via-blue-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Smartphone size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Install Native Android App</h2>
              <p className="text-xs text-cyan-400">Android WebAPK • Fullscreen Standalone</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 overflow-y-auto">
          {/* Status banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/15 to-cyan-500/10 border border-emerald-500/30 flex items-start gap-3">
            <ShieldCheck size={22} className="text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs text-white/80 leading-relaxed">
              <strong className="text-white block mb-0.5">Native Android App (WebAPK)</strong>
              Android automatically compiles this PWA into an authentic native Android app with home screen icon, splash screen, offline caching, and no browser address bar!
            </div>
          </div>

          {/* Build Details */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
            <div className="flex justify-between text-white/60">
              <span>App Name:</span>
              <span className="text-white font-medium">{assistantName} AI Voice Assistant</span>
            </div>
            <div className="flex justify-between text-white/60">
              <span>Developer:</span>
              <span className="text-cyan-300 font-semibold">ZUBAYR Interactive</span>
            </div>
            <div className="flex justify-between text-white/60">
              <span>Platform Target:</span>
              <span className="text-white font-medium">Android Standalone App</span>
            </div>
            <div className="flex justify-between text-white/60">
              <span>Engine:</span>
              <span className="text-white font-medium">Gemini 3.8 Multimodal & Live Voice</span>
            </div>
            <div className="flex justify-between text-white/60">
              <span>Language:</span>
              <span className="text-white font-medium">Bangla / Banglish / English</span>
            </div>
          </div>

          {/* Steps for Android */}
          <div className="space-y-2 text-xs text-white/70">
            <span className="font-semibold text-white">How to Install on Android in 1 Click:</span>
            <ol className="list-decimal pl-5 space-y-1.5 text-white/60">
              <li>Tap the <strong>"Install App Now"</strong> button below.</li>
              <li>Or tap Chrome's three dots <strong>(⋮)</strong> &gt; <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
              <li>Android will instantly generate and install your native app!</li>
            </ol>
          </div>

          {/* Action Button */}
          <button
            onClick={async () => {
              if ("vibrate" in navigator) navigator.vibrate([15, 30]);
              const success = await onInstall();
              if (success) onClose();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
          >
            <Download size={18} />
            <span>{isInstalled ? "App Installed Already" : "Install Native Android App Now"}</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
