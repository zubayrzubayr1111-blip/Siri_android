import React from "react";
import { motion } from "motion/react";
import { AppState } from "../types";

interface VisualizerProps {
  state: AppState;
  audioLevel?: number;
  style?: "siri-orb" | "atomic";
  assistantName?: string;
}

export default function Visualizer({
  state,
  audioLevel = 0,
  style = "siri-orb",
  assistantName = "Siri",
}: VisualizerProps) {
  // If user selected atomic gyroscope, render the 3D atomic rings
  if (style === "atomic") {
    const getSpeed = () => {
      switch (state) {
        case "listening": return 2;
        case "processing": return 1;
        case "speaking": return 0.5;
        case "reconnecting": return 1.2;
        default: return 8;
      }
    };

    const getCoreGlow = () => {
      switch (state) {
        case "listening": return "shadow-[0_0_80px_rgba(16,185,129,0.6)] bg-emerald-500";
        case "processing": return "shadow-[0_0_100px_rgba(6,182,212,0.8)] bg-cyan-400";
        case "speaking": return "shadow-[0_0_120px_rgba(236,72,153,0.8)] bg-pink-500";
        case "reconnecting": return "shadow-[0_0_90px_rgba(245,158,11,0.7)] bg-amber-500";
        default: return "shadow-[0_0_60px_rgba(59,130,246,0.4)] bg-blue-500";
      }
    };

    const corePulse = () => {
      if (state === "speaking") return { scale: [1, 1.2, 0.9, 1.1, 1], transition: { duration: 0.5, repeat: Infinity } };
      if (state === "processing") return { scale: [0.95, 1.05, 0.95], transition: { duration: 0.8, repeat: Infinity } };
      if (state === "reconnecting") return { scale: [0.9, 1.1, 0.9], transition: { duration: 0.7, repeat: Infinity } };
      if (state === "listening") return { scale: [1, 1.05, 1], transition: { duration: 1.5, repeat: Infinity } };
      return { scale: [1, 1.02, 1], transition: { duration: 4, repeat: Infinity } };
    };

    const speed = getSpeed();

    return (
      <div className="w-full h-full flex items-center justify-center relative [perspective:1000px]">
        <div className="absolute w-[280px] h-[280px] md:w-[340px] md:h-[340px] rounded-full border border-white/5" />
        <div className="relative w-[240px] h-[240px] md:w-[290px] md:h-[290px] flex items-center justify-center [transform-style:preserve-3d]">
          <motion.div
            animate={{ rotateZ: 360 }}
            transition={{ duration: speed * 1.5, repeat: Infinity, ease: "linear" }}
            className="absolute w-full h-full rounded-full border-[3px] border-cyan-400/80 shadow-[0_0_15px_rgba(6,182,212,0.5)]"
            style={{ transform: "rotateX(75deg) rotateY(25deg)", transformStyle: "preserve-3d" }}
          />
          <motion.div
            animate={{ rotateZ: -360 }}
            transition={{ duration: speed * 1.8, repeat: Infinity, ease: "linear" }}
            className="absolute w-full h-full rounded-full border-[3px] border-pink-500/80 shadow-[0_0_15px_rgba(236,72,153,0.5)]"
            style={{ transform: "rotateX(75deg) rotateY(-45deg)", transformStyle: "preserve-3d" }}
          />
          <motion.div
            animate={{ rotateZ: 360 }}
            transition={{ duration: speed * 2, repeat: Infinity, ease: "linear" }}
            className="absolute w-full h-full rounded-full border-[3px] border-emerald-400/80 shadow-[0_0_15px_rgba(52,211,153,0.5)]"
            style={{ transform: "rotateX(75deg) rotateY(85deg)", transformStyle: "preserve-3d" }}
          />
          <motion.div
            animate={{ rotateZ: -360 }}
            transition={{ duration: speed * 2.5, repeat: Infinity, ease: "linear" }}
            className="absolute w-[115%] h-[115%] rounded-full border-[1px] border-white/20"
            style={{ transform: "rotateX(80deg) rotateY(0deg)", transformStyle: "preserve-3d" }}
          />
          <motion.div
            animate={corePulse()}
            className={`absolute w-[100px] h-[100px] md:w-[120px] md:h-[120px] rounded-full z-10 transition-colors duration-500 ease-in-out ${getCoreGlow()}`}
            style={{
              background: `radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8) 0%, ${
                state === "idle" ? "#1d4ed8" : "transparent"
              } 40%, rgba(0,0,0,0.8) 100%)`,
            }}
          >
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/20 to-white/60 opacity-50" />
          </motion.div>
        </div>
      </div>
    );
  }

  // DEFAULT: Iconic Siri Glowing Fluid Chromatic Orb
  const isListening = state === "listening";
  const isSpeaking = state === "speaking";
  const isProcessing = state === "processing";
  const isReconnecting = state === "reconnecting";

  // Dynamic scale influenced by audio level or speaking pulse
  const baseScale = isSpeaking ? 1.15 : isListening ? 1.05 + Math.min(audioLevel * 1.5, 0.25) : 1.0;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative select-none">
      {/* Background Soft Chromatic Glow */}
      <motion.div
        animate={{
          scale: isSpeaking ? [1, 1.3, 1] : isProcessing ? [0.9, 1.15, 0.9] : [1, 1.08, 1],
          opacity: isSpeaking ? 0.8 : isListening ? 0.6 : 0.35,
        }}
        transition={{
          duration: isSpeaking ? 1.2 : isProcessing ? 1.5 : 4,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute w-[280px] h-[280px] md:w-[360px] md:h-[360px] rounded-full pointer-events-none blur-[70px] md:blur-[90px]"
        style={{
          background: isSpeaking
            ? "radial-gradient(circle, rgba(236,72,153,0.7) 0%, rgba(168,85,247,0.6) 40%, rgba(6,182,212,0.4) 70%, transparent 80%)"
            : isProcessing
            ? "radial-gradient(circle, rgba(6,182,212,0.7) 0%, rgba(59,130,246,0.6) 50%, rgba(147,51,234,0.3) 80%, transparent 85%)"
            : isReconnecting
            ? "radial-gradient(circle, rgba(245,158,11,0.7) 0%, rgba(239,68,68,0.5) 60%, transparent 80%)"
            : isListening
            ? "radial-gradient(circle, rgba(16,185,129,0.6) 0%, rgba(6,182,212,0.5) 50%, rgba(139,92,246,0.4) 80%, transparent 85%)"
            : "radial-gradient(circle, rgba(99,102,241,0.4) 0%, rgba(168,85,247,0.3) 50%, transparent 80%)",
        }}
      />

      {/* Outer Soundwaves / Light Ripple Rings */}
      {(isSpeaking || isListening) && (
        <>
          <motion.div
            initial={{ scale: 0.8, opacity: 0.8 }}
            animate={{ scale: [1, 1.45, 1.8], opacity: [0.7, 0.25, 0] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut" }}
            className="absolute w-[180px] h-[180px] md:w-[220px] md:h-[220px] rounded-full border-2 border-cyan-400/40 pointer-events-none"
          />
          <motion.div
            initial={{ scale: 0.8, opacity: 0.8 }}
            animate={{ scale: [1, 1.45, 1.8], opacity: [0.7, 0.25, 0] }}
            transition={{ duration: 2.2, delay: 0.7, repeat: Infinity, ease: "easeOut" }}
            className="absolute w-[180px] h-[180px] md:w-[220px] md:h-[220px] rounded-full border-2 border-pink-500/40 pointer-events-none"
          />
          <motion.div
            initial={{ scale: 0.8, opacity: 0.8 }}
            animate={{ scale: [1, 1.45, 1.8], opacity: [0.7, 0.25, 0] }}
            transition={{ duration: 2.2, delay: 1.4, repeat: Infinity, ease: "easeOut" }}
            className="absolute w-[180px] h-[180px] md:w-[220px] md:h-[220px] rounded-full border-2 border-violet-500/40 pointer-events-none"
          />
        </>
      )}

      {/* Main Siri Glowing Multi-Color Fluid Orb */}
      <motion.div
        animate={{
          scale: baseScale,
          rotate: isProcessing ? 360 : [0, 45, -45, 0],
        }}
        transition={{
          rotate: {
            duration: isProcessing ? 3 : 14,
            repeat: Infinity,
            ease: isProcessing ? "linear" : "easeInOut",
          },
          scale: {
            duration: isSpeaking ? 0.35 : 0.6,
            ease: "easeInOut",
          },
        }}
        className="relative w-[170px] h-[170px] md:w-[210px] md:h-[210px] rounded-full flex items-center justify-center shadow-2xl overflow-hidden"
        style={{
          boxShadow: isSpeaking
            ? "0 0 60px rgba(236,72,153,0.7), inset 0 0 40px rgba(255,255,255,0.6)"
            : isListening
            ? "0 0 50px rgba(52,211,153,0.6), inset 0 0 30px rgba(255,255,255,0.5)"
            : isProcessing
            ? "0 0 60px rgba(6,182,212,0.8), inset 0 0 35px rgba(255,255,255,0.6)"
            : "0 0 35px rgba(99,102,241,0.4), inset 0 0 25px rgba(255,255,255,0.3)",
        }}
      >
        {/* Layer 1: Swirling Colorful Liquid Mesh */}
        <motion.div
          animate={{
            rotate: [0, 360],
            scale: isSpeaking ? [1, 1.15, 1] : [1, 1.05, 1],
          }}
          transition={{
            rotate: { duration: isSpeaking ? 6 : isProcessing ? 3 : 16, repeat: Infinity, ease: "linear" },
            scale: { duration: 2, repeat: Infinity, ease: "easeInOut" },
          }}
          className="absolute inset-[-25%] rounded-full filter blur-[14px]"
          style={{
            background:
              "conic-gradient(from 0deg, #ec4899 0deg, #8b5cf6 70deg, #3b82f6 140deg, #06b6d4 210deg, #10b981 280deg, #ec4899 360deg)",
          }}
        />

        {/* Layer 2: Counter-Rotating Iridescent Glow Wave */}
        <motion.div
          animate={{
            rotate: [360, 0],
            opacity: [0.65, 0.95, 0.65],
          }}
          transition={{
            rotate: { duration: isSpeaking ? 8 : 20, repeat: Infinity, ease: "linear" },
            opacity: { duration: 1.8, repeat: Infinity, ease: "easeInOut" },
          }}
          className="absolute inset-[-10%] rounded-full filter blur-[8px] mix-blend-screen"
          style={{
            background:
              "radial-gradient(circle at 35% 30%, #ffffff 0%, rgba(236,72,153,0.8) 35%, rgba(6,182,212,0.8) 70%, transparent 95%)",
          }}
        />

        {/* Layer 3: Glass Sphere Specular Highlights */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background:
              "radial-gradient(circle at 30% 25%, rgba(255,255,255,0.75) 0%, rgba(255,255,255,0.15) 30%, transparent 60%)",
          }}
        />

        {/* Layer 4: Deep Rim Shadow for 3D Marble Depth */}
        <div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            boxShadow: "inset 0 -15px 30px rgba(0,0,0,0.6), inset 0 2px 10px rgba(255,255,255,0.8)",
          }}
        />

        {/* Center Waveform Pulsing Line */}
        <div className="absolute inset-0 flex items-center justify-center gap-1 z-20 pointer-events-none opacity-80">
          {[0, 1, 2, 3, 4].map((i) => (
            <motion.div
              key={i}
              animate={{
                height: isSpeaking
                  ? [10, 36, 14, 44, 12][i]
                  : isListening
                  ? [8, 20, 14, 24, 10][i] * (1 + audioLevel * 3)
                  : isProcessing
                  ? [16, 22, 16, 22, 16][i]
                  : [6, 10, 8, 12, 6][i],
                opacity: isSpeaking || isListening ? 0.9 : 0.5,
              }}
              transition={{
                duration: isSpeaking ? 0.3 + i * 0.08 : 0.6,
                repeat: Infinity,
                repeatType: "reverse",
                ease: "easeInOut",
              }}
              className="w-1.5 rounded-full bg-white shadow-[0_0_8px_#ffffff]"
            />
          ))}
        </div>
      </motion.div>

      {/* Attribution Watermark */}
      <div className="mt-6 flex flex-col items-center gap-1 pointer-events-none">
        <span className="text-xs uppercase tracking-[0.25em] text-white/50 font-medium">
          {assistantName}
        </span>
        <span className="text-[10px] tracking-[0.15em] text-white/30 uppercase">
          Engineered by ZUBAYR Interactive
        </span>
      </div>
    </div>
  );
}
