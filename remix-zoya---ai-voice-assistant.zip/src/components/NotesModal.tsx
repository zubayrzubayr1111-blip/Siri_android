import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { StickyNote, Plus, Trash2, Copy, Check, X, Sparkles } from "lucide-react";
import { VoiceNote } from "../types";

interface NotesModalProps {
  isOpen: boolean;
  onClose: () => void;
  assistantName?: string;
  notes: VoiceNote[];
  onAddNote: (text: string) => void;
  onDeleteNote: (id: string) => void;
}

export default function NotesModal({
  isOpen,
  onClose,
  assistantName = "Siri",
  notes,
  onAddNote,
  onDeleteNote,
}: NotesModalProps) {
  const [inputText, setInputText] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onAddNote(inputText.trim());
    setInputText("");
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center items-center p-0 sm:p-4 md:p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.98 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg bg-[#141622] border border-white/15 rounded-t-[28px] sm:rounded-3xl shadow-2xl shadow-black/95 flex flex-col max-h-[92dvh] overflow-hidden text-white"
      >
        <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-2 sm:hidden shrink-0" />

        <div className="shrink-0 px-4 py-3 sm:px-6 sm:py-3.5 border-b border-white/10 bg-[#161826] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-yellow-500 to-amber-600 flex items-center justify-center shadow-lg shadow-yellow-500/20">
              <StickyNote size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-white">Siri Quick Notes & Memos</h2>
              <p className="text-[11px] text-white/50">Say "Take a note..." or type anytime</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 flex items-center justify-center text-white/80 transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Input */}
        <form onSubmit={handleAdd} className="p-4 border-b border-white/10 flex gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a new note or memo..."
            className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs sm:text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-yellow-500"
          />
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-4 py-2 rounded-xl bg-yellow-500 hover:bg-yellow-600 disabled:opacity-40 text-black font-semibold text-xs flex items-center gap-1 transition-all"
          >
            <Plus size={15} />
            <span>Add</span>
          </button>
        </form>

        {/* Notes list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 max-h-[380px]">
          {notes.length === 0 ? (
            <div className="text-center py-10 text-white/40 text-xs">
              No notes saved yet. Tell {assistantName} "Take a note..." or type above!
            </div>
          ) : (
            notes.map((note) => (
              <div
                key={note.id}
                className="p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-yellow-500/40 transition-colors flex items-start justify-between gap-3"
              >
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm text-white/90 leading-relaxed whitespace-pre-wrap">
                    {note.text}
                  </p>
                  <span className="text-[10px] text-white/40 mt-1 block">
                    {note.timestamp}
                  </span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleCopy(note.id, note.text)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/60 hover:text-white transition-colors"
                    title="Copy note"
                  >
                    {copiedId === note.id ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  </button>
                  <button
                    onClick={() => onDeleteNote(note.id)}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 text-white/60 hover:text-red-400 transition-colors"
                    title="Delete note"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </motion.div>
    </div>
  );
}
