export interface AppConfig {
  apiKey: string;
  userName: string;
  assistantName: string;
  systemPrompt: string;
  voiceName?: string;
  activeTopicOrScript?: string;
  visualizerStyle?: "siri-orb" | "atomic";
  enableBackgroundRun?: boolean;
}

export type AppState = "idle" | "listening" | "processing" | "speaking" | "reconnecting";

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  category: "family" | "work" | "friend" | "emergency";
  avatarBg?: string;
}

export interface QuickMessageDraft {
  recipient: string;
  text: string;
  platform: "whatsapp" | "sms" | "email";
}

export interface ActiveTimer {
  id: string;
  label: string;
  totalSeconds: number;
  remainingSeconds: number;
  isRunning: boolean;
}

export interface VoiceNote {
  id: string;
  text: string;
  timestamp: string;
}
