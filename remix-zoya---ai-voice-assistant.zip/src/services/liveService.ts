import { GoogleGenAI, LiveServerMessage, Modality, StartSensitivity, EndSensitivity, ActivityHandling } from "@google/genai";
import { AppConfig, AppState } from "../types";
import { processCommand, CommandResult } from "./commandService";
import { DEFAULT_GEMINI_API_KEY } from "./geminiService";

// High performance Uint8Array to base64 converter avoiding heavy GC allocation
function uint8ToBase64(bytes: Uint8Array): string {
  let binary = "";
  const len = bytes.byteLength;
  const chunkSize = 2048;
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, chunk as any);
  }
  return btoa(binary);
}

// Universal audio downsampler to convert any native mic sample rate to pristine 16000Hz PCM
function downsampleTo16k(inputData: Float32Array, inputSampleRate: number): Int16Array {
  if (inputSampleRate === 16000) {
    const pcm16 = new Int16Array(inputData.length);
    for (let i = 0; i < inputData.length; i++) {
      const s = Math.max(-1, Math.min(1, inputData[i]));
      pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }
    return pcm16;
  }

  const ratio = inputSampleRate / 16000;
  const newLength = Math.round(inputData.length / ratio);
  const result = new Int16Array(newLength);
  let offsetResult = 0;
  let offsetInput = 0;

  while (offsetResult < result.length) {
    const nextOffsetInput = Math.round((offsetResult + 1) * ratio);
    let accum = 0;
    let count = 0;
    for (let i = offsetInput; i < nextOffsetInput && i < inputData.length; i++) {
      accum += inputData[i];
      count++;
    }
    const sample = count > 0 ? accum / count : 0;
    const clamped = Math.max(-1, Math.min(1, sample));
    result[offsetResult] = clamped < 0 ? clamped * 0x8000 : clamped * 0x7FFF;
    offsetResult++;
    offsetInput = nextOffsetInput;
  }
  return result;
}

export class LiveSessionManager {
  private ai: GoogleGenAI;
  private activeSession: any = null;
  private isConnecting: boolean = false;
  private isExplicitlyStopped: boolean = false;
  private reconnectTimer: any = null;
  private playbackTimeout: any = null;
  private speakingHangoverTimer: any = null;
  private processingSafetyTimer: any = null;
  private watchdogTimer: any = null;

  // Voice Activity & Audio streaming state
  private lastUserTranscript: string = "";
  private residualAudioBytes: Uint8Array | null = null;
  private isUserSpeaking: boolean = false;
  private lastAudioChunkTimestamp: number = 0;

  // Audio capture
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;

  // Audio playback state
  private playbackContext: AudioContext | null = null;
  private playbackGain: GainNode | null = null;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private nextPlayTime: number = 0;
  private isPlaying: boolean = false;

  // Background keep-alive silent audio generator
  private silentAudioElement: HTMLAudioElement | null = null;

  // Wake lock for mobile devices
  private wakeLock: any = null;

  public isMuted: boolean = false;
  public volume: number = 1.0;

  public onStateChange: (state: AppState) => void = () => {};
  public onMessage: (sender: "user" | "zoya", text: string) => void = () => {};
  public onCommandResult: (result: CommandResult) => void = () => {};
  public onCommand: (url: string) => void = () => {};
  public onAudioLevel: (level: number) => void = () => {};

  private boundVisibilityHandler: () => void;

  constructor(private config: AppConfig) {
    const key = (config?.apiKey && config.apiKey.trim()) || DEFAULT_GEMINI_API_KEY;
    this.ai = new GoogleGenAI({ apiKey: key });
    this.boundVisibilityHandler = this.handleVisibilityChange.bind(this);
    if (typeof document !== "undefined") {
      document.addEventListener("visibilitychange", this.boundVisibilityHandler);
    }
    this.setupMediaSession();
  }

  private setupMediaSession() {
    if (typeof navigator !== "undefined" && "mediaSession" in navigator) {
      try {
        const assistantName = this.config.assistantName || "Siri";
        navigator.mediaSession.metadata = new MediaMetadata({
          title: `${assistantName} Voice Assistant`,
          artist: "ZUBAYR Interactive",
          album: "Siri AI Live Companion",
          artwork: [
            { src: "/pwa-192x192.png", sizes: "192x192", type: "image/png" },
            { src: "/pwa-512x512.png", sizes: "512x512", type: "image/png" },
          ],
        });

        navigator.mediaSession.setActionHandler("pause", () => {
          this.isMuted = true;
        });
        navigator.mediaSession.setActionHandler("play", () => {
          this.isMuted = false;
        });
        navigator.mediaSession.setActionHandler("stop", () => {
          this.stop();
        });
      } catch (err) {
        console.warn("MediaSession setup warning:", err);
      }
    }
  }

  private startSilentKeepAlive() {
    try {
      if (!this.silentAudioElement && typeof document !== "undefined") {
        const silentWavBase64 =
          "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAAAP8A/w==";
        this.silentAudioElement = new Audio(silentWavBase64);
        this.silentAudioElement.loop = true;
        this.silentAudioElement.volume = 0.01;
        this.silentAudioElement.play().catch(() => {});
      }
    } catch (e) {
      console.warn("Keep-alive silent audio setup warning:", e);
    }
  }

  private stopSilentKeepAlive() {
    if (this.silentAudioElement) {
      try {
        this.silentAudioElement.pause();
        this.silentAudioElement.src = "";
      } catch {}
      this.silentAudioElement = null;
    }
  }

  private handleVisibilityChange() {
    if (typeof document !== "undefined" && document.visibilityState === "visible") {
      this.resumeAudioContexts();
      if (!this.wakeLock && !this.isExplicitlyStopped) {
        this.requestWakeLock();
      }
    }
  }

  private async resumeAudioContexts() {
    try {
      if (this.audioContext && this.audioContext.state === "suspended") {
        await this.audioContext.resume().catch(() => {});
      }
      if (this.playbackContext && this.playbackContext.state === "suspended") {
        await this.playbackContext.resume().catch(() => {});
      }
    } catch {}
  }

  private async requestWakeLock() {
    if (typeof navigator !== "undefined" && "wakeLock" in navigator) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request("screen");
      } catch {}
    }
  }

  private releaseWakeLock() {
    if (this.wakeLock) {
      try {
        this.wakeLock.release().catch(() => {});
      } catch {}
      this.wakeLock = null;
    }
  }

  private setAppProcessing() {
    this.onStateChange("processing");
    if (this.processingSafetyTimer) clearTimeout(this.processingSafetyTimer);
    // Never let app stay stuck on 'processing' longer than 3.5s
    this.processingSafetyTimer = setTimeout(() => {
      if (!this.isPlaying) {
        this.onStateChange("listening");
      }
    }, 3500);
  }

  /**
   * Emergency Watchdog to guarantee voice pipeline NEVER freezes or gets stuck
   */
  private startVoiceWatchdog() {
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);

    this.watchdogTimer = setInterval(() => {
      if (this.isExplicitlyStopped || this.isConnecting) return;

      const now = Date.now();
      const currentPlayTime = this.playbackContext?.currentTime || 0;

      // 1. Auto-resume suspended audio contexts
      if (this.playbackContext?.state === "suspended" || this.audioContext?.state === "suspended") {
        this.resumeAudioContexts();
      }

      // 2. Deadlock Detection: if isPlaying is true, but no audio chunk arrived in the last 2.2s and currentTime >= nextPlayTime
      if (this.isPlaying) {
        const timeSinceLastChunk = now - this.lastAudioChunkTimestamp;
        if (timeSinceLastChunk > 2200 && currentPlayTime >= this.nextPlayTime - 0.1) {
          // Force Unstick!
          this.unstickVoice();
        }
      }

      // 3. Audio drift check: if nextPlayTime is ahead by more than 1.2s, re-align
      if (this.nextPlayTime > currentPlayTime + 1.2) {
        this.nextPlayTime = currentPlayTime + 0.05;
      }
    }, 1000);
  }

  /**
   * Explicitly unsticks and clears all stalled voice sources and restores mic listening
   */
  public unstickVoice() {
    for (const source of this.activeSources) {
      try {
        source.stop();
        source.disconnect();
      } catch {}
    }
    this.activeSources.clear();

    if (this.playbackTimeout) {
      clearTimeout(this.playbackTimeout);
      this.playbackTimeout = null;
    }
    if (this.speakingHangoverTimer) {
      clearTimeout(this.speakingHangoverTimer);
      this.speakingHangoverTimer = null;
    }
    if (this.processingSafetyTimer) {
      clearTimeout(this.processingSafetyTimer);
      this.processingSafetyTimer = null;
    }

    if (this.playbackContext) {
      this.nextPlayTime = this.playbackContext.currentTime + 0.02;
    }
    this.isPlaying = false;
    this.residualAudioBytes = null;
    this.resumeAudioContexts();
    this.onStateChange("listening");
  }

  async start() {
    this.isExplicitlyStopped = false;
    this.onStateChange("processing");

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;

      if (!this.audioContext) {
        try {
          this.audioContext = new AudioContextClass({ sampleRate: 16000 });
        } catch {
          this.audioContext = new AudioContextClass();
        }
      }
      if (this.audioContext.state === "suspended") {
        await this.audioContext.resume().catch(() => {});
      }

      if (!this.playbackContext) {
        try {
          this.playbackContext = new AudioContextClass({ sampleRate: 24000 });
        } catch {
          this.playbackContext = new AudioContextClass();
        }
      }
      if (this.playbackContext.state === "suspended") {
        await this.playbackContext.resume().catch(() => {});
      }

      this.playbackGain = this.playbackContext.createGain();
      this.playbackGain.gain.value = this.isMuted ? 0 : this.volume;
      this.playbackGain.connect(this.playbackContext.destination);
      this.nextPlayTime = this.playbackContext.currentTime;

      // Microphone with echo cancellation and fallback constraints
      if (!this.mediaStream) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error("Microphone capture is not supported in this browser context.");
        }

        try {
          this.mediaStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              channelCount: 1,
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          });
        } catch (constraintErr: any) {
          // If overconstrained, retry with simple audio constraint
          if (
            constraintErr?.name === "OverconstrainedError" ||
            constraintErr?.name === "ConstraintNotSatisfiedError"
          ) {
            this.mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          } else {
            throw constraintErr;
          }
        }
      }

      if (!this.source && this.mediaStream && this.audioContext) {
        this.source = this.audioContext.createMediaStreamSource(this.mediaStream);
        this.processor = this.audioContext.createScriptProcessor(2048, 1, 1);

        this.processor.onaudioprocess = (e) => {
          if (!this.activeSession || this.isConnecting) return;

          const inputData = e.inputBuffer.getChannelData(0);

          // 1. RMS level
          let sumSquares = 0;
          for (let i = 0; i < inputData.length; i++) {
            sumSquares += inputData[i] * inputData[i];
          }
          const rms = Math.sqrt(sumSquares / inputData.length);
          this.onAudioLevel(rms);

          // 2. Barge-in interruption check
          if (this.isPlaying) {
            // Lower threshold (0.024) so even soft interruptions immediately cut playback and listen to user!
            if (rms > 0.024) {
              this.unstickVoice();
            } else {
              return;
            }
          }

          // 3. User voice detection
          if (rms > 0.012) {
            if (!this.isUserSpeaking) {
              this.isUserSpeaking = true;
              this.onStateChange("listening");
            }
          }

          // 4. Downsample & encode
          const pcm16 = downsampleTo16k(inputData, this.audioContext?.sampleRate || 16000);
          const uint8 = new Uint8Array(pcm16.buffer, pcm16.byteOffset, pcm16.byteLength);
          const base64Data = uint8ToBase64(uint8);

          // 5. Send to Gemini Live
          try {
            this.activeSession.sendRealtimeInput({
              audio: { data: base64Data, mimeType: "audio/pcm;rate=16000" },
              media: { data: base64Data, mimeType: "audio/pcm;rate=16000" },
            });
          } catch (err) {
            console.warn("Audio stream send warning:", err);
          }
        };

        this.source.connect(this.processor);
        const muteGain = this.audioContext.createGain();
        muteGain.gain.value = 0;
        this.processor.connect(muteGain);
        muteGain.connect(this.audioContext.destination);
      }

      await this.requestWakeLock();
      this.startSilentKeepAlive();
      this.startVoiceWatchdog();

      await this.connectLiveSession();
    } catch (error: any) {
      const isPermission =
        error?.name === "NotAllowedError" ||
        error?.name === "SecurityError" ||
        error?.name === "PermissionDeniedError" ||
        error?.message?.toLowerCase().includes("permission") ||
        error?.message?.toLowerCase().includes("denied") ||
        error?.message?.toLowerCase().includes("not allowed");

      if (isPermission) {
        console.warn("Live Session microphone access was denied or not permitted:", error?.message || error);
      } else {
        console.warn("Live Session encountered an initialization issue:", error?.message || error);
      }
      this.stop();
      throw error;
    }
  }

  private async connectLiveSession() {
    if (this.isConnecting || this.isExplicitlyStopped) return;
    this.isConnecting = true;

    const assistantName = this.config.assistantName || "Siri";
    const userName = this.config.userName || "Ashwani";

    const baseInstruction = this.config.systemPrompt
      .replace(/{userName}/g, userName)
      .replace(/{assistantName}/g, assistantName);

    // ZERO-LATENCY BANGLA / BANGLISH / ENGLISH HUMAN VOICE DIRECTIVE
    const strictFemaleAndInstantDirective = `

[CORE IDENTITY & CREATION ATTRIBUTION]
1. IDENTITY: You are "${assistantName}", an affectionate, sweet, intelligent companion crafted by ZUBAYR Interactive.
2. CREATOR ATTRIBUTION: When asked who made or created you, state in sweet Banglish or Bangla: "Ami ZUBAYR Interactive er toiri kora Siri assistant!".
3. PRIMARY LANGUAGE: BANGLA & BANGLISH. You speak naturally in sweet, contemporary Banglish (Bengali with English words) as Bengalis talk every day: "Haan bolo, ami shunchi!", "Arey bilkul!", "Mom ke WhatsApp e message pathiye dichhi!", "Tumi ekhon screen e ki korcho dekhte pacchi!".
4. VOICE & GENDER: Your voice is sweet, feminine, and heartwarming ("Kore" or "Aoede"). Never switch to a robotic or deep male voice.

[LIGHTNING FAST DIRECT HUMAN RESPONSE]
1. ZERO HESITATION: Respond immediately without thinking or pauses.
2. SHORT, SWEET & CONVERSATIONAL: Keep your spoken replies brief and lively (1 to 2 short sentences per turn).
3. MULTIMODAL & ADVANCED FEATURES: You support real-time continuous screen sharing, telling the user what they are doing on screen, WhatsApp calls, SMS, and countdown timers.
4. NATURAL FILLERS: Start naturally: "Haan bolo!", "Sure!", "Bilkul!", "Ami screen dekhchi!".`;

    let topicContext = "";
    if (this.config.activeTopicOrScript && this.config.activeTopicOrScript.trim()) {
      topicContext = `

[ACTIVE FOCUS]
"${this.config.activeTopicOrScript.trim()}"
Weave naturally into your thoughts in your own sweet, casual speaking style.`;
    }

    const rawVoice = (this.config.voiceName || "").trim();
    const validFemaleVoices = ["Kore", "Aoede"];
    const voiceToUse = validFemaleVoices.includes(rawVoice) ? rawVoice : "Kore";

    const connectConfig: any = {
      model: "gemini-3.8-live",
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceToUse } },
        },
        thinkingConfig: {
          thinkingBudget: 0,
        },
        systemInstruction: baseInstruction + strictFemaleAndInstantDirective + topicContext,
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        realtimeInputConfig: {
          automaticActivityDetection: {
            disabled: false,
            startOfSpeechSensitivity: StartSensitivity.START_SENSITIVITY_HIGH,
            endOfSpeechSensitivity: EndSensitivity.END_SENSITIVITY_HIGH,
            silenceDurationMs: 220,
            prefixPaddingMs: 80,
          },
          activityHandling: ActivityHandling.START_OF_ACTIVITY_INTERRUPTS,
        },
      },
      callbacks: {
        onopen: () => {
          console.log("Live API Connected with voice:", voiceToUse);
          this.isConnecting = false;
          this.onStateChange("listening");
        },
        onmessage: async (message: LiveServerMessage) => {
          // 1. Voice activity events from server VAD
          if (message.voiceActivity?.voiceActivityType === "ACTIVITY_START") {
            if (this.isPlaying) {
              this.unstickVoice();
            }
            this.isUserSpeaking = true;
            this.onStateChange("listening");
          } else if (message.voiceActivity?.voiceActivityType === "ACTIVITY_END") {
            this.isUserSpeaking = false;
            this.setAppProcessing();
          }

          // 2. Audio Chunks
          let audioFound = false;
          const parts = message.serverContent?.modelTurn?.parts || [];
          for (const part of parts) {
            if (part.inlineData?.data) {
              audioFound = true;
              this.playAudioChunk(part.inlineData.data);
            }
          }
          if (!audioFound && (message as any).data) {
            this.playAudioChunk((message as any).data);
          }

          // 3. Barge-in notification from server
          if (message.serverContent?.interrupted) {
            this.unstickVoice();
          }

          // 4. Turn Complete
          if (message.serverContent?.turnComplete) {
            if (this.processingSafetyTimer) {
              clearTimeout(this.processingSafetyTimer);
              this.processingSafetyTimer = null;
            }
            // If turn completed and no audio is currently playing, return to listening
            if (this.activeSources.size === 0 && !this.isPlaying) {
              this.onStateChange("listening");
            } else {
              // Safety hangover: once turn completes, ensure voice unsticks within max 1.5s
              setTimeout(() => {
                if (this.activeSources.size === 0) {
                  this.isPlaying = false;
                  this.onStateChange("listening");
                }
              }, 1200);
            }
          }

          // 5. Companion Transcriptions
          const companionText =
            message.serverContent?.outputTranscription?.text ||
            message.serverContent?.modelTurn?.parts?.find((p) => p.text)?.text;
          if (companionText && companionText.trim()) {
            this.onMessage("zoya", companionText.trim());
            this.detectAndTriggerAction(companionText.trim());
          }

          // 6. User Transcription
          const userTranscription = message.serverContent?.inputTranscription?.text;
          if (
            userTranscription &&
            userTranscription.trim() &&
            userTranscription.trim() !== this.lastUserTranscript
          ) {
            this.lastUserTranscript = userTranscription.trim();
            this.onMessage("user", this.lastUserTranscript);
            this.detectAndTriggerAction(this.lastUserTranscript);
          }
        },
        onclose: () => {
          console.log("Live API connection closed.");
          this.activeSession = null;
          this.isConnecting = false;
          if (!this.isExplicitlyStopped) {
            this.scheduleReconnect();
          }
        },
        onerror: (err: any) => {
          console.error("Live API error:", err);
          this.activeSession = null;
          this.isConnecting = false;
          if (!this.isExplicitlyStopped) {
            this.scheduleReconnect();
          }
        },
      },
    };

    try {
      this.activeSession = await this.ai.live.connect(connectConfig);
      this.isConnecting = false;
      this.onStateChange("listening");
    } catch (err) {
      console.warn("Primary live model connect failed, trying fallback:", err);
      connectConfig.model = "gemini-3.1-flash-live-preview";
      try {
        this.activeSession = await this.ai.live.connect(connectConfig);
        this.isConnecting = false;
        this.onStateChange("listening");
      } catch (fallbackErr) {
        this.isConnecting = false;
        console.error("Fallback live connection failed:", fallbackErr);
        if (!this.isExplicitlyStopped) {
          this.scheduleReconnect();
        } else {
          throw fallbackErr;
        }
      }
    }
  }

  private detectAndTriggerAction(text: string) {
    // If user says "unstick voice" or "reset voice" or "stop talking"
    const lower = text.toLowerCase();
    if (
      lower.includes("unstick") ||
      lower.includes("reset voice") ||
      lower.includes("stop talking") ||
      lower.includes("chup koro") ||
      lower.includes("quiet") ||
      lower.includes("silence")
    ) {
      this.unstickVoice();
      return;
    }

    const res = processCommand(text, this.config.assistantName || "Siri");
    if (res.isBrowserAction && res.url) {
      this.onCommand(res.url);
    }
    if (res.type && res.type !== "general") {
      this.onCommandResult(res);
    }
  }

  private scheduleReconnect() {
    if (this.isExplicitlyStopped) return;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);

    this.onStateChange("reconnecting");
    console.log("Attempting smooth auto-reconnect to Live API in 1.2s...");

    this.reconnectTimer = setTimeout(async () => {
      if (this.isExplicitlyStopped) return;
      try {
        await this.connectLiveSession();
      } catch (e) {
        console.error("Auto-reconnect attempt failed, scheduling next retry...", e);
        this.scheduleReconnect();
      }
    }, 1200);
  }

  // Robust 24kHz 16-bit PCM playback with jitter buffer & deadlock prevention
  private playAudioChunk(base64Data: string) {
    if (!this.playbackContext || this.isMuted) return;

    this.lastAudioChunkTimestamp = Date.now();

    if (this.playbackContext.state === "suspended") {
      this.playbackContext.resume().catch(() => {});
    }

    try {
      const binaryString = atob(base64Data);
      const newLen = binaryString.length;
      if (newLen === 0) return;

      let rawBytes: Uint8Array;
      if (this.residualAudioBytes && this.residualAudioBytes.length > 0) {
        rawBytes = new Uint8Array(this.residualAudioBytes.length + newLen);
        rawBytes.set(this.residualAudioBytes, 0);
        for (let i = 0; i < newLen; i++) {
          rawBytes[this.residualAudioBytes.length + i] = binaryString.charCodeAt(i);
        }
        this.residualAudioBytes = null;
      } else {
        rawBytes = new Uint8Array(newLen);
        for (let i = 0; i < newLen; i++) {
          rawBytes[i] = binaryString.charCodeAt(i);
        }
      }

      if (rawBytes.length % 2 !== 0) {
        this.residualAudioBytes = rawBytes.slice(rawBytes.length - 1);
        rawBytes = rawBytes.subarray(0, rawBytes.length - 1);
      }

      const numSamples = rawBytes.length / 2;
      if (numSamples === 0) return;

      const audioBuffer = this.playbackContext.createBuffer(1, numSamples, 24000);
      const channelData = audioBuffer.getChannelData(0);
      const dataView = new DataView(rawBytes.buffer, rawBytes.byteOffset, rawBytes.byteLength);

      for (let i = 0; i < numSamples; i++) {
        channelData[i] = dataView.getInt16(i * 2, true) / 32768.0;
      }

      const source = this.playbackContext.createBufferSource();
      source.buffer = audioBuffer;

      if (this.playbackGain) {
        this.playbackGain.gain.value = this.isMuted ? 0 : this.volume;
        source.connect(this.playbackGain);
      } else {
        source.connect(this.playbackContext.destination);
      }

      const currentTime = this.playbackContext.currentTime;

      // JITTER CLAMP: nextPlayTime must be within [currentTime, currentTime + 0.6s]
      // If nextPlayTime drifted into the past or far future, re-align!
      if (this.nextPlayTime < currentTime || this.nextPlayTime > currentTime + 0.6) {
        this.nextPlayTime = currentTime + 0.015;
      }

      source.start(this.nextPlayTime);
      this.nextPlayTime += audioBuffer.duration;
      this.isPlaying = true;

      if (this.processingSafetyTimer) {
        clearTimeout(this.processingSafetyTimer);
        this.processingSafetyTimer = null;
      }
      this.onStateChange("speaking");

      this.activeSources.add(source);

      // Independent safety timeout per source node: guarantees source is cleaned up even if onended doesn't fire!
      const sourceDurationMs = Math.max(100, audioBuffer.duration * 1000 + 250);
      setTimeout(() => {
        if (this.activeSources.has(source)) {
          this.activeSources.delete(source);
          if (this.activeSources.size === 0) {
            this.isPlaying = false;
            this.onStateChange("listening");
          }
        }
      }, sourceDurationMs);

      source.onended = () => {
        this.activeSources.delete(source);
        if (this.activeSources.size === 0) {
          if (this.speakingHangoverTimer) clearTimeout(this.speakingHangoverTimer);
          this.speakingHangoverTimer = setTimeout(() => {
            if (this.activeSources.size === 0) {
              this.isPlaying = false;
              this.onStateChange("listening");
            }
          }, 60);
        }
      };

      if (this.playbackTimeout) clearTimeout(this.playbackTimeout);
      const remainingTimeMs = Math.max(150, (this.nextPlayTime - currentTime) * 1000 + 250);
      this.playbackTimeout = setTimeout(() => {
        if (this.activeSources.size === 0 && this.isPlaying) {
          this.isPlaying = false;
          this.onStateChange("listening");
        }
      }, remainingTimeMs);
    } catch (e) {
      console.error("Error playing audio chunk", e);
    }
  }

  public stopPlayback() {
    this.unstickVoice();
  }

  public sendScreenFrame(base64Jpeg: string) {
    if (this.activeSession) {
      try {
        const cleanData = base64Jpeg.includes(",") ? base64Jpeg.split(",")[1] : base64Jpeg;
        this.activeSession.sendRealtimeInput({
          media: {
            mimeType: "image/jpeg",
            data: cleanData,
          },
        });
      } catch (err) {
        console.warn("Screen frame send warning:", err);
      }
    }
  }

  stop() {
    this.isExplicitlyStopped = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.processingSafetyTimer) {
      clearTimeout(this.processingSafetyTimer);
      this.processingSafetyTimer = null;
    }
    if (this.watchdogTimer) {
      clearInterval(this.watchdogTimer);
      this.watchdogTimer = null;
    }

    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }

    this.unstickVoice();
    this.stopSilentKeepAlive();

    if (this.audioContext) {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }

    if (this.playbackContext) {
      this.playbackContext.close().catch(() => {});
      this.playbackContext = null;
    }

    if (this.activeSession) {
      try {
        this.activeSession.close();
      } catch {}
      this.activeSession = null;
    }

    this.releaseWakeLock();

    if (typeof document !== "undefined") {
      document.removeEventListener("visibilitychange", this.boundVisibilityHandler);
    }

    this.onStateChange("idle");
  }

  updateConfig(newConfig: AppConfig) {
    const rawVoice = (newConfig.voiceName || "").trim();
    const validFemaleVoices = ["Kore", "Aoede"];
    const sanitizedVoice = validFemaleVoices.includes(rawVoice) ? rawVoice : "Kore";
    newConfig.voiceName = sanitizedVoice;

    const voiceChanged = this.config.voiceName !== sanitizedVoice;
    this.config = newConfig;
    this.setupMediaSession();

    if (voiceChanged && this.activeSession && !this.isExplicitlyStopped) {
      try {
        this.activeSession.close();
      } catch {}
      this.activeSession = null;
      this.isConnecting = false;
      this.connectLiveSession().catch((e) => console.error("Error reconnecting with new voice:", e));
      return;
    }

    if (this.activeSession && newConfig.activeTopicOrScript?.trim()) {
      try {
        this.activeSession.sendRealtimeInput({
          text: `[SYSTEM: Active topic or focus updated to: "${newConfig.activeTopicOrScript.trim()}". Weave naturally into conversation.]`,
        });
      } catch (e) {
        console.warn("Could not notify active session of topic update:", e);
      }
    }
  }

  sendText(text: string) {
    if (this.activeSession) {
      try {
        this.activeSession.sendRealtimeInput({ text });
      } catch (err) {
        console.warn("Failed to send text input:", err);
      }
    }
  }
}
