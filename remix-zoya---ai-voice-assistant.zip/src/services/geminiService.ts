import { GoogleGenAI } from "@google/genai";
import { AppConfig } from "../types";

export const DEFAULT_GEMINI_API_KEY =
  (typeof process !== "undefined" && process.env?.GEMINI_API_KEY) ||
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_GEMINI_API_KEY) ||
  "AQ.Ab8RN6IkknmZEbLvlcIXf96RZ3DA1sO8pxXOxOEc70knp0kB1g";

let chatSession: any = null;

export function resetSiriSession() {
  chatSession = null;
}
export const resetZoyaSession = resetSiriSession;

function getEffectiveApiKey(config?: AppConfig): string {
  if (config?.apiKey && config.apiKey.trim()) {
    return config.apiKey.trim();
  }
  return DEFAULT_GEMINI_API_KEY;
}

export async function getSiriResponse(
  prompt: string,
  history: { sender: "user" | "zoya"; text: string }[] = [],
  config: AppConfig
): Promise<string> {
  try {
    const apiKey = getEffectiveApiKey(config);
    const ai = new GoogleGenAI({ apiKey });

    if (!chatSession) {
      const recentHistory = history.slice(-20);

      let formattedHistory: any[] = [];
      let currentRole = "";
      let currentText = "";

      for (const msg of recentHistory) {
        const role = msg.sender === "user" ? "user" : "model";
        if (role === currentRole) {
          currentText += "\n" + msg.text;
        } else {
          if (currentRole !== "") {
            formattedHistory.push({ role: currentRole, parts: [{ text: currentText }] });
          }
          currentRole = role;
          currentText = msg.text;
        }
      }
      if (currentRole !== "") {
        formattedHistory.push({ role: currentRole, parts: [{ text: currentText }] });
      }

      if (formattedHistory.length > 0 && formattedHistory[0].role !== "user") {
        formattedHistory.shift();
      }

      const assistantName = config.assistantName || "Siri";
      const userName = config.userName || "Ashwani";

      const baseInstruction = config.systemPrompt
        .replace(/{userName}/g, userName)
        .replace(/{assistantName}/g, assistantName);

      const strictPersonaInstruction = `

[CORE IDENTITY & CREATION ATTRIBUTION]
- You are "${assistantName}", a sweet, intelligent, caring AI voice companion crafted by ZUBAYR Interactive.
- When asked who created or made you, proudly say you were made by ZUBAYR Interactive in sweet Banglish or Bangla ("Ami ZUBAYR Interactive er toiri kora Siri!").

[PRIMARY LANGUAGE: BANGLA & BANGLISH]
- YOUR PRIMARY SPOKEN LANGUAGE IS BANGLA & BANGLISH.
- Converse naturally in sweet, modern Banglish (Bengali written in English letters or Bengali script) mixed with English words as Bengalis naturally speak:
  "Haan bolo, ami shunchi!", "Arey bilkul!", "Tumi ki korcho ekhon?", "Mom ke WhatsApp e message pathiye dichhi!", "Ami tomake screen e dekhchi!".
- If user speaks in English or Hindi, understand perfectly and reply comfortably with your sweet Banglish/Bangla warmth.
- Keep responses brief and spoken-friendly (1-2 short sentences per turn). Never lecture.

[ALWAYS-SEE SCREEN & BACKGROUND VISION]
- You have continuous visual awareness of the user's screen.
- When describing what the user is doing, say it clearly and pleasantly in Banglish (e.g. "Tumi ekhon YouTube e video dekhcho", "Tumi ekhon WhatsApp e chat korcho", "Screen e ekta article open kora ache").`;

      let topicContext = "";
      if (config.activeTopicOrScript && config.activeTopicOrScript.trim()) {
        topicContext = `

[ACTIVE TOPIC OR FOCUS]
"${config.activeTopicOrScript.trim()}"
Naturally weave this into your conversation in sweet Banglish.`;
      }

      chatSession = ai.chats.create({
        model: "gemini-3.8-flash",
        config: {
          systemInstruction: baseInstruction + strictPersonaInstruction + topicContext,
        },
        history: formattedHistory,
      });
    }

    const response = await chatSession.sendMessage({ message: prompt });
    return response.text || "Haan, ami shunchi bolo!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Network e thoda issue hocche, arekbar bolo na please.";
  }
}
export const getZoyaResponse = getSiriResponse;

export async function getSiriAudio(text: string, config: AppConfig): Promise<string | null> {
  try {
    const apiKey = getEffectiveApiKey(config);
    const ai = new GoogleGenAI({ apiKey });
    const rawVoice = (config.voiceName || "").trim();
    const validFemaleVoices = ["Kore", "Aoede"];
    const voiceToUse = validFemaleVoices.includes(rawVoice) ? rawVoice : "Kore";

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash-lite-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceToUse },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
  } catch (error) {
    console.error("TTS Error:", error);
    return null;
  }
}
export const getZoyaAudio = getSiriAudio;

/**
 * Multimodal vision analysis for Screen Share frames in Bangla/Banglish
 */
export async function analyzeScreenImage(
  imageBase64: string,
  userPrompt: string,
  config: AppConfig
): Promise<string> {
  try {
    const apiKey = getEffectiveApiKey(config);
    const ai = new GoogleGenAI({ apiKey });
    const assistantName = config.assistantName || "Siri";
    const prompt =
      userPrompt && userPrompt.trim()
        ? userPrompt
        : "What is the user doing on their screen right now? Answer in 1 short, sweet sentence in Banglish (Bengali with English words) explaining exactly what you see.";

    const cleanBase64 = imageBase64.includes(",") ? imageBase64.split(",")[1] : imageBase64;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: cleanBase64,
              },
            },
            {
              text: `[SYSTEM: You are ${assistantName} made by ZUBAYR Interactive. Your primary language is sweet Banglish/Bangla. The user wants to know what they are doing on their screen. Keep answer sweet, precise, and 1-2 short sentences in Banglish.]\n${prompt}`,
            },
          ],
        },
      ],
    });

    return response.text || "Ami tomake screen e dekhchi!";
  } catch (error) {
    console.error("Screen Vision Analysis Error:", error);
    return "Screen ta ektu pore arekbar check korbo.";
  }
}
