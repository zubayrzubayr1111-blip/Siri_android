export interface CommandResult {
  action: string;
  url?: string;
  isBrowserAction: boolean;
  type?: "link" | "call" | "message" | "screen" | "always_screen" | "timer" | "note" | "weather" | "general" | "unstick";
  payload?: any;
}

// Built-in Contacts Directory with nicknames (Mom/Ammu, Dad/Abbu, etc.)
export const DEFAULT_CONTACT_BOOK: Record<string, { name: string; phone: string; whatsapp: string }> = {
  mom: { name: "Mom", phone: "+15550199", whatsapp: "+15550199" },
  ammu: { name: "Ammu (Mom)", phone: "+15550199", whatsapp: "+15550199" },
  maa: { name: "Maa", phone: "+15550199", whatsapp: "+15550199" },
  dad: { name: "Dad", phone: "+15550188", whatsapp: "+15550188" },
  abbu: { name: "Abbu (Dad)", phone: "+15550188", whatsapp: "+15550188" },
  baba: { name: "Baba", phone: "+15550188", whatsapp: "+15550188" },
  zubayr: { name: "ZUBAYR Interactive", phone: "+1800982297", whatsapp: "+1800982297" },
  emergency: { name: "Emergency Services", phone: "911", whatsapp: "911" },
  police: { name: "Police", phone: "999", whatsapp: "999" },
};

export function resolveContact(nameOrNumber: string): { displayName: string; phoneNumber: string } {
  const cleanKey = nameOrNumber.toLowerCase().trim().replace(/['"]/g, "");
  if (DEFAULT_CONTACT_BOOK[cleanKey]) {
    return {
      displayName: DEFAULT_CONTACT_BOOK[cleanKey].name,
      phoneNumber: DEFAULT_CONTACT_BOOK[cleanKey].phone,
    };
  }
  // Check if it's already a phone number
  const isDigits = /^[\d\+\s\-\(\)]+$/.test(nameOrNumber);
  const digitsOnly = nameOrNumber.replace(/[^\d\+]/g, "");
  return {
    displayName: nameOrNumber,
    phoneNumber: isDigits ? digitsOnly : "",
  };
}

export function processCommand(command: string, assistantName: string = "Siri"): CommandResult {
  const lowerCmd = command.toLowerCase().trim();

  // 0. Unstick Voice & Reset Voice Command
  if (
    lowerCmd.includes("unstick") ||
    lowerCmd.includes("fix voice") ||
    lowerCmd.includes("reset voice") ||
    lowerCmd.includes("stop talking") ||
    lowerCmd.includes("chup koro") ||
    lowerCmd.includes("chup") ||
    lowerCmd === "quiet" ||
    lowerCmd === "silence" ||
    lowerCmd === "shuno"
  ) {
    return {
      action: `Voice pipeline reset kora hoyeche, ami shunchi bolo!`,
      isBrowserAction: false,
      type: "unstick",
    };
  }

  // 1. ZUBAYR Interactive Creator attribution
  if (
    lowerCmd.includes("who made you") ||
    lowerCmd.includes("who created you") ||
    lowerCmd.includes("who developed you") ||
    lowerCmd.includes("who is your creator") ||
    lowerCmd.includes("who built you") ||
    lowerCmd.includes("kisne banaya") ||
    lowerCmd.includes("kare toiri") ||
    lowerCmd.includes("ke banayse") ||
    lowerCmd.includes("ke banieche") ||
    lowerCmd.includes("tomake ke banieche")
  ) {
    return {
      action: `Ami ZUBAYR Interactive er toiri kora advanced AI Siri assistant!`,
      isBrowserAction: false,
      type: "general",
    };
  }

  // 2. Continuous Background Screen Monitoring ("Always see background and tell me what I am doing")
  if (
    lowerCmd.includes("always see") ||
    lowerCmd.includes("always watch") ||
    lowerCmd.includes("always look") ||
    lowerCmd.includes("background e dekho") ||
    lowerCmd.includes("screen e ki hocche bolo") ||
    lowerCmd.includes("tell me what i am doing") ||
    lowerCmd.includes("tell me what i'm doing") ||
    lowerCmd.includes("what am i doing") ||
    lowerCmd.includes("ami ki korchi") ||
    lowerCmd.includes("watch my screen") ||
    lowerCmd.includes("auto monitor")
  ) {
    return {
      action: `Ami screen continuous dekhchi ar bolchi tumi ki korcho!`,
      isBrowserAction: false,
      type: "always_screen",
    };
  }

  // 3. Regular Screen Share
  if (
    lowerCmd.includes("share screen") ||
    lowerCmd.includes("share my screen") ||
    lowerCmd.includes("start screen share") ||
    lowerCmd.includes("screen share koro") ||
    lowerCmd.includes("look at my screen") ||
    lowerCmd.includes("what is on my screen") ||
    lowerCmd.includes("what's on my screen") ||
    lowerCmd.includes("analyze my screen") ||
    lowerCmd.includes("screen dekho")
  ) {
    return {
      action: `Screen share open korchi, jate ami tomake dekhe shahajjo korte pari.`,
      isBrowserAction: false,
      type: "screen",
    };
  }

  // 4. WhatsApp Calling: e.g. "call mom in whatsapp", "whatsapp call mom", "call ammu on whatsapp", "mom ke whatsapp e call koro"
  const waCallMatch =
    lowerCmd.match(/^(?:call|phone)\s+([\w\s\d\+]+)\s+(?:in|on)\s+whatsapp$/i) ||
    lowerCmd.match(/^whatsapp(?:\s+e)?\s+call\s+([\w\s\d\+]+)$/i) ||
    lowerCmd.match(/^whatsapp\s+call\s+to\s+([\w\s\d\+]+)$/i) ||
    lowerCmd.match(/^([\w\s\d\+]+)\s+ke\s+whatsapp\s*(?:e)?\s+call\s+koro$/i);

  if (waCallMatch) {
    const rawTarget = waCallMatch[1].trim();
    const contact = resolveContact(rawTarget);
    const phone = contact.phoneNumber || "+15550199";
    const cleanDigits = phone.replace(/[^\d\+]/g, "");

    return {
      action: `${contact.displayName} ke WhatsApp e call korchi...`,
      url: `https://api.whatsapp.com/send?phone=${cleanDigits}&text=Calling%20via%20Siri...`,
      isBrowserAction: true,
      type: "call",
      payload: {
        target: `${contact.displayName} (WhatsApp)`,
        phoneNumber: cleanDigits,
        isWhatsApp: true,
      },
    };
  }

  // 5. Advanced Natural Messaging: e.g. "message mom I want to go park", "text mom I want to go park", "mom ke message koro I want to go park"
  const natMsgMatch =
    lowerCmd.match(/^(?:message|text|send\s+message\s+to)\s+([\w\d\+]+)\s+(?:saying\s+|that\s+|to\s+|:\s+)?(.+)$/i) ||
    lowerCmd.match(/^([\w\d\+]+)\s+ke\s+message\s+(?:koro|pathao)\s+(?:je\s+|boli\s+|:\s+)?(.+)$/i) ||
    lowerCmd.match(/^([\w\d\+]+)\s+ke\s+bolo\s+(.+)$/i);

  if (natMsgMatch && !lowerCmd.startsWith("call")) {
    const rawTarget = natMsgMatch[1].trim();
    const rawText = natMsgMatch[2].trim();

    // Check if target is not a system keyword
    if (!["whatsapp", "sms", "email", "me", "this"].includes(rawTarget)) {
      const contact = resolveContact(rawTarget);
      const phone = contact.phoneNumber || "+15550199";
      const cleanDigits = phone.replace(/[^\d\+]/g, "");
      const encoded = encodeURIComponent(rawText);

      return {
        action: `${contact.displayName} ke message pathiye dichhi: "${rawText}"`,
        url: `https://api.whatsapp.com/send?phone=${cleanDigits}&text=${encoded}`,
        isBrowserAction: true,
        type: "message",
        payload: {
          recipient: contact.displayName,
          phoneNumber: cleanDigits,
          message: rawText,
          platform: "whatsapp",
        },
      };
    }
  }

  // 6. Explicit WhatsApp Message: "send a whatsapp message to [number] saying [message]"
  const waMsgMatch =
    lowerCmd.match(/^(?:send\s+a\s+)?whatsapp(?:\s+message)?\s+(?:to\s+)?([\+\d\s\w]+)\s+(?:saying|that)\s+(.+)$/i) ||
    lowerCmd.match(/^send\s+a\s+whatsapp\s+message\s+to\s+([\+\d\s\w]+)\s*:\s*(.+)$/i);
  if (waMsgMatch) {
    const rawRecipient = waMsgMatch[1].trim();
    const message = waMsgMatch[2].trim();
    const contact = resolveContact(rawRecipient);
    const cleanNumber = contact.phoneNumber || rawRecipient.replace(/[^\d\+]/g, "");
    const encoded = encodeURIComponent(message);
    const url = cleanNumber
      ? `https://api.whatsapp.com/send?phone=${cleanNumber}&text=${encoded}`
      : `https://api.whatsapp.com/send?text=${encoded}`;
    return {
      action: `${contact.displayName} ke WhatsApp e message pathacchi: "${message}"`,
      url,
      isBrowserAction: true,
      type: "message",
      payload: { recipient: contact.displayName, message, platform: "whatsapp" },
    };
  }

  // 7. General Phone Call / Dial
  // e.g. "call mom", "call dad", "call 12345", "dial 9876543210", "mom ke call koro"
  const generalCallMatch =
    lowerCmd.match(/^(?:call|dial|phone|make a call to)\s+([\+\d\s\w]+)$/i) ||
    lowerCmd.match(/^([\+\d\s\w]+)\s+ke\s+call\s+koro$/i);
  if (generalCallMatch) {
    const rawTarget = generalCallMatch[1].trim();
    const contact = resolveContact(rawTarget);
    const phone = contact.phoneNumber;
    const cleanDigits = phone.replace(/[\s\-\(\)]/g, "");

    return {
      action: `${contact.displayName} ke call korchi...`,
      url: cleanDigits ? `tel:${cleanDigits}` : undefined,
      isBrowserAction: false,
      type: "call",
      payload: {
        target: contact.displayName,
        phoneNumber: cleanDigits,
      },
    };
  }

  // 8. Send SMS
  const smsMatch =
    lowerCmd.match(/^(?:send\s+(?:an?\s+)?(?:sms|text)(?:\s+message)?\s+(?:to\s+)?([\+\d\s\w]+)\s+(?:saying|that)\s+(.+))$/i) ||
    lowerCmd.match(/^(?:text|sms)\s+([\+\d\s\w]+)\s+(?:saying|that)\s+(.+)$/i);
  if (smsMatch) {
    const recipient = smsMatch[1].trim();
    const message = smsMatch[2].trim();
    const contact = resolveContact(recipient);
    const cleanNumber = contact.phoneNumber || recipient.replace(/[^\d\+]/g, "");
    const encoded = encodeURIComponent(message);
    return {
      action: `${contact.displayName} ke SMS pathacchi: "${message}"`,
      url: `sms:${cleanNumber}?body=${encoded}`,
      isBrowserAction: false,
      type: "message",
      payload: { recipient: contact.displayName, message, platform: "sms" },
    };
  }

  // 9. Timers & Alarms
  const timerMatch = lowerCmd.match(/^(?:set\s+(?:a\s+)?)?timer(?:\s+for)?\s+(\d+)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)/i);
  if (timerMatch) {
    const value = parseInt(timerMatch[1], 10);
    const unit = timerMatch[2].toLowerCase();
    let totalSeconds = value;
    if (unit.startsWith("min")) {
      totalSeconds = value * 60;
    } else if (unit.startsWith("hour") || unit.startsWith("hr")) {
      totalSeconds = value * 3600;
    }
    return {
      action: `${value} ${unit} er timer start korchi!`,
      isBrowserAction: false,
      type: "timer",
      payload: { seconds: totalSeconds, label: `${value} ${unit}` },
    };
  }

  // 10. Take a note / Memo
  const noteMatch =
    lowerCmd.match(/^(?:take\s+(?:a\s+)?note|note\s+that|remember\s+(?:that|to)?)\s+(.+)$/i) ||
    lowerCmd.match(/^(?:note\s+koro|mone\s+rakho)\s+(.+)$/i);
  if (noteMatch) {
    const noteText = noteMatch[1].trim();
    return {
      action: `Thik ache! Note save kore rakhlam: "${noteText}"`,
      isBrowserAction: false,
      type: "note",
      payload: { text: noteText },
    };
  }

  // 11. Maps / Navigation
  const navMatch = lowerCmd.match(/^(?:navigate\s+to|directions\s+to|maps?\s+(?:to|for))\s+(.+)$/i);
  if (navMatch) {
    const destination = encodeURIComponent(navMatch[1].trim());
    return {
      action: `${navMatch[1]} er map open korchi.`,
      url: `https://www.google.com/maps/dir/?api=1&destination=${destination}`,
      isBrowserAction: true,
      type: "link",
    };
  }

  // 12. Media Search: YouTube & Spotify
  const ytMatch = lowerCmd.match(/^play\s+(.+?)\s+on\s+youtube$/i) || lowerCmd.match(/(?:play|chalao|bajao)\s+(.+?)\s+youtube\s*(?:e|par|pe)?$/i);
  if (ytMatch) {
    const query = encodeURIComponent(ytMatch[1].trim());
    return {
      action: `YouTube e "${ytMatch[1]}" play korchi.`,
      url: `https://www.youtube.com/results?search_query=${query}`,
      isBrowserAction: true,
      type: "link",
    };
  }

  const spotifyMatch = lowerCmd.match(/^(?:search|play)\s+(.+?)\s+on\s+spotify$/i);
  if (spotifyMatch) {
    const query = encodeURIComponent(spotifyMatch[1].trim());
    return {
      action: `Spotify te "${spotifyMatch[1]}" search korchi.`,
      url: `https://open.spotify.com/search/${query}`,
      isBrowserAction: true,
      type: "link",
    };
  }

  return { action: "", isBrowserAction: false, type: "general" };
}
