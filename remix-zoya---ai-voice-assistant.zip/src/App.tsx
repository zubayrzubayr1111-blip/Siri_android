import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Mic,
  MicOff,
  Loader2,
  Volume2,
  VolumeX,
  Keyboard,
  Send,
  Trash2,
  Video,
  Settings,
  MoreVertical,
  Edit3,
  Key,
  Download,
  ScrollText,
  RefreshCw,
  Phone,
  MessageSquare,
  Monitor,
  Timer,
  StickyNote,
  Layers,
  Radio,
  Sparkles,
  RotateCcw,
  HelpCircle,
} from "lucide-react";
import {
  getSiriResponse,
  getSiriAudio,
  resetSiriSession,
  analyzeScreenImage,
  DEFAULT_GEMINI_API_KEY,
} from "./services/geminiService";
import { usePWAInstall } from "./hooks/usePWAInstall";
import { processCommand, CommandResult } from "./services/commandService";
import { LiveSessionManager } from "./services/liveService";
import Visualizer from "./components/Visualizer";
import PermissionModal from "./components/PermissionModal";
import SetupScreen from "./components/SetupScreen";
import TopicScriptModal from "./components/TopicScriptModal";
import VoiceSelectorModal from "./components/VoiceSelectorModal";
import ScreenShareDock from "./components/ScreenShareDock";
import CallModal from "./components/CallModal";
import MessageModal from "./components/MessageModal";
import TimerModal from "./components/TimerModal";
import NotesModal from "./components/NotesModal";
import ActionDrawer from "./components/ActionDrawer";
import VoiceCommandsModal from "./components/VoiceCommandsModal";
import AndroidInstallModal from "./components/AndroidInstallModal";
import { playPCM } from "./utils/audioUtils";
import { motion, AnimatePresence } from "motion/react";
import { AppConfig, AppState, QuickMessageDraft, ActiveTimer, VoiceNote } from "./types";

interface ChatMessage {
  id: string;
  sender: "user" | "zoya";
  text: string;
}

export default function App() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);

  // Initialize config with Siri defaults and integrated API key
  const [config, setConfig] = useState<AppConfig>(() => {
    try {
      const savedSiri = localStorage.getItem("siri_app_config");
      if (savedSiri) {
        const parsed = JSON.parse(savedSiri);
        if (!parsed.apiKey || parsed.apiKey.trim() === "") {
          parsed.apiKey = DEFAULT_GEMINI_API_KEY;
        }
        parsed.assistantName = "Siri";
        if (parsed.voiceName !== "Aoede") {
          parsed.voiceName = "Kore";
        }
        return parsed;
      }
      const savedOld = localStorage.getItem("zoya_app_config");
      if (savedOld) {
        const parsed = JSON.parse(savedOld);
        if (!parsed.apiKey || parsed.apiKey.trim() === "") {
          parsed.apiKey = DEFAULT_GEMINI_API_KEY;
        }
        parsed.assistantName = "Siri";
        if (parsed.voiceName !== "Aoede") {
          parsed.voiceName = "Kore";
        }
        localStorage.setItem("siri_app_config", JSON.stringify(parsed));
        return parsed;
      }
    } catch (e) {
      console.warn("Failed to load siri_app_config:", e);
    }
    return {
      apiKey: DEFAULT_GEMINI_API_KEY,
      userName: "Ashwani",
      assistantName: "Siri",
      systemPrompt: "",
      voiceName: "Kore",
      visualizerStyle: "siri-orb",
      enableBackgroundRun: true,
    };
  });

  const [appState, setAppState] = useState<AppState>("idle");
  const [audioLevel, setAudioLevel] = useState<number>(0);

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem("siri_chat_history") || localStorage.getItem("zoya_chat_history");
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Failed to parse chat history:", e);
    }
    return [];
  });
  const messagesRef = useRef(messages);

  useEffect(() => {
    messagesRef.current = messages;
    try {
      localStorage.setItem("siri_chat_history", JSON.stringify(messages));
    } catch (e) {
      console.warn("Failed to save chat history:", e);
    }
  }, [messages]);

  useEffect(() => {
    const assistant = config?.assistantName || "Siri";
    document.title = `${assistant} - AI Voice Assistant | ZUBAYR Interactive`;
  }, [config?.assistantName]);

  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1.0);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  // New Modals and Drawers
  const [showActionDrawer, setShowActionDrawer] = useState(false);
  const [showCallModal, setShowCallModal] = useState(false);
  const [callTarget, setCallTarget] = useState("Siri");
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageDraft, setMessageDraft] = useState<QuickMessageDraft | null>(null);
  const [showTimerModal, setShowTimerModal] = useState(false);
  const [activeTimer, setActiveTimer] = useState<ActiveTimer | null>(null);
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [notes, setNotes] = useState<VoiceNote[]>(() => {
    try {
      const saved = localStorage.getItem("siri_voice_notes");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Screen Share State
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isAlwaysWatching, setIsAlwaysWatching] = useState(false);
  const [isWhatsAppCall, setIsWhatsAppCall] = useState(false);
  const [showVoiceCommandsModal, setShowVoiceCommandsModal] = useState(false);
  const [showAndroidInstallModal, setShowAndroidInstallModal] = useState(false);

  // Background run & visualizer style preferences
  const [enableBackgroundRun, setEnableBackgroundRun] = useState<boolean>(() => {
    return config?.enableBackgroundRun ?? true;
  });
  const [visualizerStyle, setVisualizerStyle] = useState<"siri-orb" | "atomic">(() => {
    return config?.visualizerStyle || "siri-orb";
  });

  useEffect(() => {
    try {
      localStorage.setItem("siri_voice_notes", JSON.stringify(notes));
    } catch {}
  }, [notes]);

  const liveSessionRef = useRef<LiveSessionManager | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.isMuted = isMuted;
      liveSessionRef.current.volume = volume;
    }
  }, [isMuted, volume]);

  const [showTextInput, setShowTextInput] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isMicHearing, setIsMicHearing] = useState(false);

  const [videoSrc, setVideoSrc] = useState<string | null>(() => {
    try {
      return localStorage.getItem("siri_video_bg") || null;
    } catch {
      return null;
    }
  });

  const [showTopicModal, setShowTopicModal] = useState(false);
  const [showVoiceModal, setShowVoiceModal] = useState(false);
  const [updatingPWA, setUpdatingPWA] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, appState]);

  // Config updater
  const handleConfigComplete = (newConfig: AppConfig) => {
    if (!newConfig.assistantName || newConfig.assistantName.trim() === "") {
      newConfig.assistantName = "Siri";
    }
    if (newConfig.voiceName !== "Aoede") {
      newConfig.voiceName = "Kore";
    }
    newConfig.visualizerStyle = newConfig.visualizerStyle || visualizerStyle;
    newConfig.enableBackgroundRun = newConfig.enableBackgroundRun ?? enableBackgroundRun;

    try {
      localStorage.setItem("siri_app_config", JSON.stringify(newConfig));
    } catch (e) {
      console.warn("Failed to save config:", e);
    }
    setConfig(newConfig);
    setVisualizerStyle(newConfig.visualizerStyle);
    setEnableBackgroundRun(newConfig.enableBackgroundRun);
    setShowSettings(false);
    resetSiriSession();
    if (liveSessionRef.current) {
      liveSessionRef.current.updateConfig(newConfig);
    }
  };

  const handleSelectVoice = (newVoice: string) => {
    if (!config) return;
    const sanitizedVoice = newVoice === "Aoede" ? "Aoede" : "Kore";
    const updatedConfig: AppConfig = {
      ...config,
      voiceName: sanitizedVoice,
    };
    setConfig(updatedConfig);
    try {
      localStorage.setItem("siri_app_config", JSON.stringify(updatedConfig));
    } catch (e) {
      console.warn("Failed to save config voice:", e);
    }
    resetSiriSession();
    if (liveSessionRef.current) {
      liveSessionRef.current.updateConfig(updatedConfig);
    }
  };

  const handleUpdateTopic = (newTopic: string) => {
    if (!config) return;
    const updatedConfig: AppConfig = {
      ...config,
      activeTopicOrScript: newTopic,
    };
    setConfig(updatedConfig);
    try {
      localStorage.setItem("siri_app_config", JSON.stringify(updatedConfig));
    } catch (e) {
      console.warn("Failed to save config topic:", e);
    }
    resetSiriSession();
    if (liveSessionRef.current) {
      liveSessionRef.current.updateConfig(updatedConfig);
    }
  };

  // Screen share start/stop
  const handleStartScreenShare = async (autoWatch = false) => {
    try {
      if (screenStream) {
        if (autoWatch) {
          setIsAlwaysWatching(true);
        } else {
          handleStopScreenShare();
        }
        return;
      }
      const stream = await (navigator.mediaDevices as any).getDisplayMedia({
        video: {
          cursor: "always",
        },
        audio: false,
      });
      setScreenStream(stream);
      setIsScreenSharing(true);
      if (autoWatch) {
        setIsAlwaysWatching(true);
      }

      // Announce in chat
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now().toString() + "-z",
          sender: "zoya",
          text: autoWatch
            ? `Ami continuously screen dekhchi ar bolchi tumi ki korcho!`
            : `Ami tomader screen dekhchi! Screen e ki hocche jigesh korte paro.`,
        },
      ]);
    } catch (err) {
      console.warn("Screen share was cancelled or failed:", err);
      setIsScreenSharing(false);
      setScreenStream(null);
      setIsAlwaysWatching(false);
    }
  };

  const handleStopScreenShare = useCallback(() => {
    if (screenStream) {
      screenStream.getTracks().forEach((track) => track.stop());
    }
    setScreenStream(null);
    setIsScreenSharing(false);
    setIsAlwaysWatching(false);
  }, [screenStream]);

  // Frame analysis from screen share
  const handleAnalyzeScreenFrame = async (imageBase64: string, prompt?: string) => {
    if (!config) return;
    setAppState("processing");
    const userPrompt = prompt || "Analyze this screen and tell me in Banglish what the user is doing.";
    setMessages((prev) => [
      ...prev,
      { id: Date.now().toString(), sender: "user", text: `[Screen Vision]: ${userPrompt}` },
    ]);

    // If live session is active, also stream frame
    if (isSessionActive && liveSessionRef.current) {
      liveSessionRef.current.sendScreenFrame(imageBase64);
    }

    const answer = await analyzeScreenImage(imageBase64, userPrompt, config);
    setMessages((prev) => [
      ...prev,
      { id: Date.now().toString() + "-z", sender: "zoya", text: answer },
    ]);

    if (!isMuted) {
      setAppState("speaking");
      const audio = await getSiriAudio(answer, config);
      if (audio) {
        await playPCM(audio, volume);
      }
    }
    setAppState(isSessionActive ? "listening" : "idle");
  };

  // Process rich action results (Calls, Messages, Timers, Notes)
  const handleExecuteCommandResult = useCallback(
    (cmd: CommandResult) => {
      if (!cmd) return;

      if ("vibrate" in navigator) navigator.vibrate(15);

      if (cmd.type === "always_screen") {
        setIsAlwaysWatching(true);
        handleStartScreenShare(true);
      } else if (cmd.type === "call") {
        setCallTarget(cmd.payload?.target || "Siri");
        setIsWhatsAppCall(Boolean(cmd.payload?.isWhatsApp));
        setShowCallModal(true);
        if (cmd.url && !cmd.payload?.isWhatsApp) {
          window.open(cmd.url, "_self");
        } else if (cmd.url && cmd.payload?.isWhatsApp) {
          window.open(cmd.url, "_blank");
        }
      } else if (cmd.type === "message") {
        setMessageDraft({
          recipient: cmd.payload?.recipient || "",
          text: cmd.payload?.message || "",
          platform: cmd.payload?.platform || "whatsapp",
        });
        setShowMessageModal(true);
        if (cmd.url) {
          // Open WhatsApp web/app directly with prefilled text
          window.open(cmd.url, "_blank");
        }
      } else if (cmd.type === "screen") {
        handleStartScreenShare();
      } else if (cmd.type === "timer") {
        const secs = cmd.payload?.seconds || 300;
        setActiveTimer({
          id: Date.now().toString(),
          label: cmd.payload?.label || "Timer",
          totalSeconds: secs,
          remainingSeconds: secs,
          isRunning: true,
        });
        setShowTimerModal(true);
      } else if (cmd.type === "unstick") {
        if ("vibrate" in navigator) navigator.vibrate([20, 40]);
        if (liveSessionRef.current) {
          liveSessionRef.current.unstickVoice();
        }
        setAppState("listening");
      } else if (cmd.type === "note") {
        const text = cmd.payload?.text || "";
        if (text) {
          setNotes((prev) => [
            {
              id: Date.now().toString(),
              text,
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            },
            ...prev,
          ]);
        }
      }
    },
    []
  );

  const handleUnstickVoice = useCallback(() => {
    if ("vibrate" in navigator) navigator.vibrate([15, 30]);
    if (liveSessionRef.current) {
      liveSessionRef.current.unstickVoice();
    }
    setAppState(isSessionActive ? "listening" : "idle");
  }, [isSessionActive]);

  // Command input handler
  const handleTextCommand = useCallback(
    async (finalTranscript: string) => {
      if (!finalTranscript.trim() || !config) {
        setAppState("idle");
        return;
      }

      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), sender: "user", text: finalTranscript },
      ]);

      // If live session is active, send text through it
      if (isSessionActive && liveSessionRef.current) {
        liveSessionRef.current.sendText(finalTranscript);
        return;
      }

      setAppState("processing");

      // 1. Check for command
      const commandResult = processCommand(finalTranscript, config.assistantName || "Siri");

      if (commandResult.type && commandResult.type !== "general") {
        handleExecuteCommandResult(commandResult);
      }

      let responseText = "";

      if (commandResult.isBrowserAction && commandResult.url) {
        responseText = commandResult.action;
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString() + "-z", sender: "zoya", text: responseText },
        ]);

        if (!isMuted) {
          setAppState("speaking");
          const audioBase64 = await getSiriAudio(responseText, config);
          if (audioBase64) {
            await playPCM(audioBase64, isMuted ? 0 : volume);
          }
        }

        setAppState("idle");
        setTimeout(() => {
          if (commandResult.url) {
            window.open(commandResult.url, "_blank");
          }
        }, 1200);
      } else {
        // General Chat via Gemini
        responseText = await getSiriResponse(finalTranscript, messagesRef.current, config);
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString() + "-z", sender: "zoya", text: responseText },
        ]);

        if (!isMuted) {
          setAppState("speaking");
          const audioBase64 = await getSiriAudio(responseText, config);
          if (audioBase64) {
            await playPCM(audioBase64, isMuted ? 0 : volume);
          }
        }
        setAppState("idle");
      }
    },
    [isMuted, volume, isSessionActive, config, handleExecuteCommandResult]
  );

  useEffect(() => {
    return () => {
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
      }
      handleStopScreenShare();
    };
  }, [handleStopScreenShare]);

  const toggleListening = async () => {
    if (isSessionActive) {
      setIsSessionActive(false);
      setIsMicHearing(false);
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
        liveSessionRef.current = null;
      }
      setAppState("idle");
      resetSiriSession();
    } else {
      if (!config) return;
      try {
        setIsSessionActive(true);
        resetSiriSession();

        const session = new LiveSessionManager(config);
        session.isMuted = isMuted;
        session.volume = volume;
        liveSessionRef.current = session;

        session.onStateChange = (state) => {
          setAppState(state);
          if (state === "idle") {
            setIsSessionActive(false);
          } else {
            setIsSessionActive(true);
          }
        };

        session.onMessage = (sender, text) => {
          setMessages((prev) => [
            ...prev,
            { id: Date.now().toString() + "-" + sender, sender, text },
          ]);
        };

        session.onCommandResult = (cmd) => {
          handleExecuteCommandResult(cmd);
        };

        session.onCommand = (url) => {
          setTimeout(() => {
            window.open(url, "_blank");
          }, 1000);
        };

        session.onAudioLevel = (level) => {
          setAudioLevel(level);
          if (level > 0.012) {
            setIsMicHearing(true);
          } else if (level < 0.005) {
            setIsMicHearing(false);
          }
        };

        await session.start();
      } catch (e: any) {
        const isPermission =
          e?.name === "NotAllowedError" ||
          e?.name === "SecurityError" ||
          e?.name === "PermissionDeniedError" ||
          e?.message?.toLowerCase().includes("permission") ||
          e?.message?.toLowerCase().includes("denied") ||
          e?.message?.toLowerCase().includes("not allowed");

        if (isPermission) {
          console.warn("Microphone permission was not granted; opening permission helper & enabling text chat mode:", e?.message || e);
        } else {
          console.warn("Live voice session could not be started:", e?.message || e);
        }

        setShowPermissionModal(true);
        setIsSessionActive(false);
        setIsMicHearing(false);
        setAppState("idle");
        setShowTextInput(true);
      }
    }
  };

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;

    handleTextCommand(textInput);
    setTextInput("");
    setShowTextInput(false);
  };

  const handleForceUpdateApp = async () => {
    setUpdatingPWA(true);
    try {
      if ("serviceWorker" in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const reg of registrations) {
          await reg.unregister();
        }
      }
      if ("caches" in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((name) => caches.delete(name)));
      }
    } catch (e) {
      console.warn("Cache reset error:", e);
    } finally {
      window.location.reload();
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setVideoSrc(url);
      try {
        localStorage.setItem("siri_video_bg", url);
      } catch {}
    }
  };

  if (!config) {
    return <SetupScreen onComplete={handleConfigComplete} />;
  }

  const assistantName = config.assistantName || "Siri";

  return (
    <div
      className="h-[100dvh] w-screen bg-[#06080F] text-white flex flex-col items-center justify-between font-sans relative overflow-hidden m-0 p-0"
      onClick={() => {
        setMenuOpen(false);
        setShowVolumeSlider(false);
      }}
    >
      {/* Background Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-35">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-cyan-600/20 blur-[130px] rounded-full" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-purple-600/20 blur-[130px] rounded-full" />
      </div>

      {showSettings && (
        <SetupScreen
          initialConfig={config}
          onComplete={handleConfigComplete}
          onCancel={() => setShowSettings(false)}
        />
      )}
      {showPermissionModal && (
        <PermissionModal
          assistantName={assistantName}
          onClose={() => setShowPermissionModal(false)}
          onRetry={() => {
            setShowPermissionModal(false);
            toggleListening();
          }}
          onSwitchToText={() => {
            setShowPermissionModal(false);
            setShowTextInput(true);
          }}
        />
      )}

      {/* Screen Share Floating Dock */}
      <AnimatePresence>
        {isScreenSharing && screenStream && (
          <ScreenShareDock
            stream={screenStream}
            onStop={handleStopScreenShare}
            onAnalyzeFrame={handleAnalyzeScreenFrame}
            assistantName={assistantName}
            isAlwaysWatching={isAlwaysWatching}
            onToggleAlwaysWatch={(val) => setIsAlwaysWatching(val)}
          />
        )}
      </AnimatePresence>

      {/* Phone Call Screen Modal */}
      <CallModal
        isOpen={showCallModal}
        onClose={() => setShowCallModal(false)}
        assistantName={assistantName}
        initialTarget={callTarget}
        isWhatsApp={isWhatsAppCall}
        isMicMuted={isMuted}
        onToggleMicMute={() => setIsMuted(!isMuted)}
        appState={appState}
        onStartScreenShare={handleStartScreenShare}
        isScreenSharing={isScreenSharing}
      />

      {/* Send Message Modal */}
      <MessageModal
        isOpen={showMessageModal}
        onClose={() => setShowMessageModal(false)}
        initialDraft={messageDraft}
        assistantName={assistantName}
      />

      {/* Timers & Countdown Modal */}
      <TimerModal
        isOpen={showTimerModal}
        onClose={() => setShowTimerModal(false)}
        activeTimer={activeTimer}
        assistantName={assistantName}
        onSetTimer={(secs, label) => {
          setActiveTimer({
            id: Date.now().toString(),
            label,
            totalSeconds: secs,
            remainingSeconds: secs,
            isRunning: true,
          });
        }}
      />

      {/* Voice Notes Modal */}
      <NotesModal
        isOpen={showNotesModal}
        onClose={() => setShowNotesModal(false)}
        assistantName={assistantName}
        notes={notes}
        onAddNote={(text) => {
          setNotes((prev) => [
            {
              id: Date.now().toString(),
              text,
              timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            },
            ...prev,
          ]);
        }}
        onDeleteNote={(id) => {
          setNotes((prev) => prev.filter((n) => n.id !== id));
        }}
      />

      {/* Action Drawer / Siri Control Center */}
      <ActionDrawer
        isOpen={showActionDrawer}
        onClose={() => setShowActionDrawer(false)}
        assistantName={assistantName}
        onOpenCall={() => {
          setCallTarget("Siri");
          setShowCallModal(true);
        }}
        onOpenMessage={() => setShowMessageModal(true)}
        onToggleScreenShare={handleStartScreenShare}
        isScreenSharing={isScreenSharing}
        onOpenTimer={() => setShowTimerModal(true)}
        onOpenNotes={() => setShowNotesModal(true)}
        onOpenSettings={() => setShowSettings(true)}
        onOpenVoiceCommands={() => setShowVoiceCommandsModal(true)}
        onOpenAndroidInstall={() => setShowAndroidInstallModal(true)}
        onUnstickVoice={handleUnstickVoice}
        enableBackgroundRun={enableBackgroundRun}
        onToggleBackgroundRun={(val) => {
          setEnableBackgroundRun(val);
          const updated = { ...config, enableBackgroundRun: val };
          setConfig(updated);
          localStorage.setItem("siri_app_config", JSON.stringify(updated));
        }}
        visualizerStyle={visualizerStyle}
        onToggleVisualizerStyle={(st) => {
          setVisualizerStyle(st);
          const updated = { ...config, visualizerStyle: st };
          setConfig(updated);
          localStorage.setItem("siri_app_config", JSON.stringify(updated));
        }}
      />

      {/* PWA iOS Guide */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-3xl bg-[#181A22] p-8 border border-white/10 shadow-2xl flex flex-col items-center text-center gap-6">
            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-2">
              <Download size={32} className="text-cyan-400" />
            </div>
            <div>
              <h3 className="text-xl font-medium text-white mb-2">Install on iOS</h3>
              <p className="text-sm text-white/60 leading-relaxed">
                To install {assistantName} on your iPhone or iPad:
                <br />
                <br />
                1. Tap the <strong>Share</strong> button in Safari.
                <br />
                2. Tap <strong>Add to Home Screen</strong>.
              </p>
            </div>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-3 mt-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors text-white font-medium"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="w-full flex justify-between items-center z-20 shrink-0 px-6 py-5 md:px-12 md:py-6 border-b border-white/5 bg-[#06080F]/60 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowActionDrawer(true)}
            className="flex items-center gap-2 group text-left cursor-pointer"
            title="Open Siri Control Center"
          >
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-cyan-400 via-purple-500 to-pink-500 p-0.5 shadow-md shadow-purple-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full rounded-[14px] bg-[#0A0C14] flex items-center justify-center">
                <Sparkles size={16} className="text-cyan-300" />
              </div>
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-bold tracking-[0.2em] uppercase text-white group-hover:text-cyan-300 transition-colors leading-none">
                {assistantName}
              </h1>
              <span className="text-[10px] tracking-wider uppercase text-cyan-400 font-semibold block mt-0.5">
                by ZUBAYR Interactive
              </span>
            </div>
          </button>
        </div>

        {/* Action Header Icons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Always-Watch Screen Button */}
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate([15, 30]);
              if (!screenStream) {
                handleStartScreenShare(true);
              } else {
                setIsAlwaysWatching(!isAlwaysWatching);
              }
            }}
            className={`p-2 sm:p-2.5 rounded-xl border flex items-center gap-1.5 transition-all ${
              isAlwaysWatching && isScreenSharing
                ? "bg-emerald-500/25 text-emerald-300 border-emerald-400 shadow-md shadow-emerald-500/20"
                : "bg-[#141622] hover:bg-[#1E2232] text-white/70 hover:text-white border-white/10"
            }`}
            title="Always see background & tell me what I am doing"
          >
            <span className={`w-2 h-2 rounded-full ${isAlwaysWatching && isScreenSharing ? "bg-emerald-400 animate-ping" : "bg-white/30"}`} />
            <span className="text-[11px] font-semibold hidden md:inline">
              {isAlwaysWatching && isScreenSharing ? "Auto Vision: ON" : "Auto Vision"}
            </span>
          </button>

          {/* Screen Share Button */}
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(15);
              handleStartScreenShare();
            }}
            className={`p-2.5 sm:p-3 rounded-xl border transition-all ${
              isScreenSharing
                ? "bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-md shadow-cyan-500/20 animate-pulse"
                : "bg-[#141622] hover:bg-[#1E2232] text-white/80 hover:text-white border-white/10"
            }`}
            title={isScreenSharing ? "Screen Share Active" : "Share Screen"}
          >
            <Monitor size={18} />
          </button>

          {/* Quick Call Button */}
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(15);
              setCallTarget("Mom (Ammu)");
              setIsWhatsAppCall(true);
              setShowCallModal(true);
            }}
            className="p-2.5 sm:p-3 rounded-xl bg-[#141622] hover:bg-[#1E2232] text-white/80 hover:text-emerald-400 border border-white/10 shadow transition-colors"
            title="Phone & WhatsApp Call"
          >
            <Phone size={18} />
          </button>

          {/* Quick Message Button */}
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(15);
              setShowMessageModal(true);
            }}
            className="p-2.5 sm:p-3 rounded-xl bg-[#141622] hover:bg-[#1E2232] text-white/80 hover:text-cyan-400 border border-white/10 shadow transition-colors"
            title="Send Message (WhatsApp/SMS/Email)"
          >
            <MessageSquare size={18} />
          </button>

          {/* Siri Action Drawer / Control Center Toggle */}
          <button
            onClick={() => {
              if ("vibrate" in navigator) navigator.vibrate(15);
              setShowActionDrawer(true);
            }}
            className="p-2.5 sm:p-3 rounded-xl bg-gradient-to-r from-purple-600/30 to-pink-600/30 hover:from-purple-600/50 hover:to-pink-600/50 text-white border border-purple-500/30 shadow transition-all"
            title="Siri Tools & Actions"
          >
            <Layers size={18} className="text-purple-300" />
          </button>

          {/* Settings Menu Dropdown */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setMenuOpen(!menuOpen);
              }}
              className="p-2.5 sm:p-3 rounded-xl bg-[#141622] hover:bg-[#1E2232] border border-white/10 shadow transition-colors text-white/80 hover:text-white"
              title="Settings"
            >
              <Settings size={18} />
            </button>

            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 top-full mt-2 w-52 bg-[#141624] border border-white/10 rounded-2xl shadow-2xl py-1.5 z-50 overflow-hidden"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowSettings(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3"
                  >
                    <Edit3 size={15} className="text-cyan-400" />
                    Configure Siri
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowVoiceModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <Volume2 size={15} className="text-pink-400" />
                    <div className="flex-1 flex items-center justify-between">
                      <span>Voice</span>
                      <span className="text-[10px] text-pink-300 font-medium px-2 py-0.5 rounded-full bg-pink-500/15">
                        {config?.voiceName || "Kore"}
                      </span>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowTopicModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <ScrollText size={15} className="text-amber-400" />
                    <span>Topic & Script Focus</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowNotesModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <StickyNote size={15} className="text-yellow-400" />
                    <span>Quick Notes ({notes.length})</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowTimerModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <Timer size={15} className="text-amber-400" />
                    <span>Timer & Alarms</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowVoiceCommandsModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-cyan-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <HelpCircle size={15} />
                    <span>Voice Commands Guide</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      setShowAndroidInstallModal(true);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-emerald-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <Download size={15} />
                    <span>Install Native Android App</span>
                  </button>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      handleUnstickVoice();
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-amber-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <RotateCcw size={15} />
                    <span>Unstick / Reset Voice</span>
                  </button>

                  <label className="w-full text-left px-4 py-3 text-xs sm:text-sm text-white/90 hover:bg-white/5 transition-colors flex items-center gap-3 cursor-pointer border-t border-white/5">
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => {
                        handleVideoUpload(e);
                        setMenuOpen(false);
                      }}
                    />
                    <Video size={15} className="text-purple-400" />
                    <span>{videoSrc ? "Change Video" : "Upload Video BG"}</span>
                  </label>

                  <button
                    onClick={() => {
                      setMenuOpen(false);
                      handleForceUpdateApp();
                    }}
                    disabled={updatingPWA}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-emerald-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <RefreshCw size={15} className={updatingPWA ? "animate-spin" : ""} />
                    <span>{updatingPWA ? "Updating..." : "Refresh App Cache"}</span>
                  </button>

                  <button
                    onClick={() => {
                      if (confirm("Are you sure you want to clear memory and chat history?")) {
                        setMessages([]);
                        resetSiriSession();
                        localStorage.removeItem("siri_chat_history");
                      }
                      setMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-3 text-xs sm:text-sm text-red-400 hover:bg-white/5 transition-colors flex items-center gap-3 border-t border-white/5"
                  >
                    <Trash2 size={15} />
                    <span>Clear Memory</span>
                  </button>

                  <div className="px-4 py-2 border-t border-white/10 text-[10px] text-cyan-400 font-mono tracking-wider text-center bg-black/30">
                    ZUBAYR INTERACTIVE
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      {/* Video Background if uploaded */}
      {videoSrc && (
        <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden bg-black flex items-center justify-center">
          <video
            src={videoSrc}
            autoPlay
            loop
            muted={true}
            playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-40 blur-2xl scale-110"
          />
          <video
            src={videoSrc}
            autoPlay
            loop
            muted={true}
            playsInline
            className="relative w-full h-full object-contain opacity-90 z-10"
          />
        </div>
      )}

      {/* Main Center Stage */}
      <main className="flex-1 w-full flex flex-col items-center justify-center px-4 relative z-10">
        {/* Status Pill Header */}
        <div className="absolute top-3 w-full flex justify-center z-20 pointer-events-none">
          <AnimatePresence>
            {appState === "processing" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 text-cyan-300 text-xs sm:text-sm bg-black/70 px-4 py-1.5 rounded-full backdrop-blur-md border border-cyan-500/30 shadow-lg shadow-cyan-500/10"
              >
                <Loader2 size={14} className="animate-spin text-cyan-400" />
                <span>{assistantName} is thinking...</span>
              </motion.div>
            )}
            {appState === "listening" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 text-emerald-300 text-xs sm:text-sm bg-black/70 px-4 py-1.5 rounded-full backdrop-blur-md border border-emerald-500/30 shadow-lg shadow-emerald-500/10"
              >
                <div
                  className={`w-2 h-2 rounded-full transition-all duration-200 ${
                    isMicHearing
                      ? "bg-emerald-300 scale-125 shadow-[0_0_10px_#34d399]"
                      : "bg-emerald-400 animate-pulse"
                  }`}
                />
                <span>{isMicHearing ? "Hearing you..." : "Listening..."}</span>
              </motion.div>
            )}
            {appState === "speaking" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 text-pink-300 text-xs sm:text-sm bg-black/70 px-4 py-1.5 rounded-full backdrop-blur-md border border-pink-500/30 shadow-lg shadow-pink-500/10"
              >
                <Volume2 size={14} className="animate-pulse text-pink-400" />
                <span>{assistantName} Speaking...</span>
              </motion.div>
            )}
            {appState === "reconnecting" && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center gap-2 text-amber-300 text-xs sm:text-sm bg-black/70 px-4 py-1.5 rounded-full backdrop-blur-md border border-amber-500/30 shadow-lg shadow-amber-500/10"
              >
                <Loader2 size={14} className="animate-spin text-amber-400" />
                <span>Reconnecting...</span>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quick Unstick & Voice Commands Shortcut */}
          <div className="flex items-center gap-1.5 pointer-events-auto ml-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleUnstickVoice();
              }}
              className="p-1.5 rounded-full bg-black/60 hover:bg-white/10 text-white/50 hover:text-amber-300 border border-white/10 backdrop-blur-md transition-colors"
              title="Unstick / Reset Voice Audio"
            >
              <RotateCcw size={13} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowVoiceCommandsModal(true);
              }}
              className="p-1.5 rounded-full bg-black/60 hover:bg-white/10 text-white/50 hover:text-cyan-300 border border-white/10 backdrop-blur-md transition-colors"
              title="Voice Commands Guide"
            >
              <HelpCircle size={13} />
            </button>
          </div>
        </div>

        {/* Visualizer Card */}
        {!videoSrc && (
          <div
            onClick={toggleListening}
            title={isSessionActive ? "Tap to end session" : "Tap to speak with Siri"}
            className="w-full max-w-[420px] aspect-[4/4.5] sm:aspect-[4/5] rounded-[36px] bg-[#0E111C]/80 border border-white/10 shadow-2xl relative overflow-hidden flex items-center justify-center cursor-pointer transition-transform hover:scale-[1.01] active:scale-[0.99] backdrop-blur-xl"
          >
            <Visualizer
              state={appState}
              audioLevel={audioLevel}
              style={visualizerStyle}
              assistantName={assistantName}
            />
          </div>
        )}
      </main>

      {/* Footer Controls */}
      <footer className="w-full flex flex-col items-center justify-center pb-8 pt-4 px-6 z-20 shrink-0 gap-4 border-t border-white/5 bg-[#06080F]/70 backdrop-blur-xl">
        {/* Text Input Row */}
        <AnimatePresence>
          {showTextInput && (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              onSubmit={handleTextSubmit}
              className="w-full max-w-md flex items-center gap-2 bg-white/5 border border-white/10 rounded-full p-1 pl-4 backdrop-blur-md shadow-2xl"
            >
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder={`Ask ${assistantName} anything, call, message, or share...`}
                className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/30 text-xs sm:text-sm"
                autoFocus
              />
              <button
                type="submit"
                disabled={!textInput.trim()}
                className="p-2.5 rounded-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 disabled:opacity-40 transition-colors"
              >
                <Send size={15} />
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        {/* Primary Action Buttons */}
        <div className="w-full max-w-sm flex items-center justify-center gap-3">
          {/* Keyboard Toggle */}
          <button
            onClick={() => setShowTextInput(!showTextInput)}
            className={`p-3.5 sm:p-4 rounded-2xl border transition-colors shadow-lg ${
              showTextInput
                ? "bg-white/20 border-white/30 text-white"
                : "bg-[#141624] border-white/10 text-white/70 hover:text-white hover:bg-[#1E2234]"
            }`}
            title="Text Message input"
          >
            <Keyboard size={18} />
          </button>

          {/* Big Mic / Initialize Session Button */}
          <button
            onClick={toggleListening}
            className={`flex-1 relative flex items-center justify-center gap-2 py-3.5 sm:py-4 rounded-2xl font-semibold tracking-wide transition-all duration-300 shadow-xl cursor-pointer ${
              isSessionActive
                ? "bg-red-500/20 text-red-400 border border-red-500/50 hover:bg-red-500/30"
                : "bg-gradient-to-r from-cyan-500 via-purple-600 to-pink-600 hover:from-cyan-400 hover:to-pink-500 text-white shadow-purple-600/30"
            }`}
          >
            {appState === "reconnecting" ? (
              <>
                <Loader2 size={18} className="animate-spin text-amber-300" />
                <span className="text-xs sm:text-sm text-amber-300">Reconnecting...</span>
              </>
            ) : isSessionActive ? (
              <>
                <MicOff size={18} />
                <span className="text-xs sm:text-sm">End Voice Session</span>
              </>
            ) : (
              <>
                <Mic size={18} />
                <span className="text-xs sm:text-sm">Talk to {assistantName}</span>
              </>
            )}
          </button>

          {/* Volume Button */}
          <div className="relative flex items-center justify-center">
            <AnimatePresence>
              {showVolumeSlider && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9, y: 10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute bottom-full mb-4 px-4 py-3 bg-[#141624] border border-white/10 rounded-2xl shadow-2xl z-50 flex items-center justify-center min-w-[120px]"
                  onClick={(e) => e.stopPropagation()}
                >
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={isMuted ? 0 : volume}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setVolume(val);
                      if (val === 0) setIsMuted(true);
                      else setIsMuted(false);
                    }}
                    className="w-full h-1.5 bg-white/20 rounded-full appearance-none cursor-pointer accent-white"
                  />
                </motion.div>
              )}
            </AnimatePresence>

            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowVolumeSlider(!showVolumeSlider);
              }}
              className={`p-3.5 sm:p-4 rounded-2xl border transition-colors shadow-lg ${
                showVolumeSlider
                  ? "bg-[#252836] border-white/20 text-white"
                  : "bg-[#141624] border-white/10 text-white/70 hover:text-white hover:bg-[#1E2234]"
              }`}
              title="Volume"
            >
              {isMuted || volume === 0 ? (
                <VolumeX size={18} className="text-white/40" />
              ) : (
                <Volume2 size={18} className="text-white/80" />
              )}
            </button>
          </div>
        </div>

        {/* Small Attribution Footer */}
        <div className="text-[10px] tracking-widest uppercase text-white/30 flex items-center gap-1.5">
          <span>{assistantName} AI</span>
          <span>•</span>
          <span className="text-cyan-400/70 font-semibold">Crafted by ZUBAYR Interactive</span>
        </div>
      </footer>

      {/* Topic & Script Focus Modal */}
      {showTopicModal && (
        <TopicScriptModal
          assistantName={assistantName}
          currentTopic={config?.activeTopicOrScript || ""}
          onSave={handleUpdateTopic}
          onClose={() => setShowTopicModal(false)}
        />
      )}

      {/* Voice Selection Modal */}
      {showVoiceModal && (
        <VoiceSelectorModal
          assistantName={assistantName}
          currentVoice={config?.voiceName || "Kore"}
          onSelectVoice={handleSelectVoice}
          onClose={() => setShowVoiceModal(false)}
        />
      )}

      {/* Voice Commands Guide Modal */}
      <VoiceCommandsModal
        isOpen={showVoiceCommandsModal}
        onClose={() => setShowVoiceCommandsModal(false)}
        assistantName={assistantName}
        onTestCommand={(cmd) => handleTextCommand(cmd)}
      />

      {/* Android Native Install Modal */}
      <AndroidInstallModal
        isOpen={showAndroidInstallModal}
        onClose={() => setShowAndroidInstallModal(false)}
        onInstall={install}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        assistantName={assistantName}
      />
    </div>
  );
}
