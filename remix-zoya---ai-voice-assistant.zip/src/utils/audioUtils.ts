export async function playPCM(base64Data: string, volume: number = 1.0): Promise<void> {
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) {
      console.warn("AudioContext not supported");
      return;
    }
    const audioCtx = new AudioContextClass({ sampleRate: 24000 });
    if (audioCtx.state === "suspended") {
      await audioCtx.resume().catch(() => {});
    }

    const binaryString = atob(base64Data);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    const buffer = new Int16Array(bytes.buffer);
    const audioBuffer = audioCtx.createBuffer(1, buffer.length, 24000);
    const channelData = audioBuffer.getChannelData(0);
    for (let i = 0; i < buffer.length; i++) {
      channelData[i] = buffer[i] / 32768.0;
    }
    const source = audioCtx.createBufferSource();
    source.buffer = audioBuffer;

    const gainNode = audioCtx.createGain();
    gainNode.gain.value = volume;

    source.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    source.start();

    // Guard against promise deadlocks: ALWAYS resolve with safety timeout
    return new Promise<void>((resolve) => {
      let isDone = false;
      const cleanup = () => {
        if (!isDone) {
          isDone = true;
          try {
            source.disconnect();
            gainNode.disconnect();
            audioCtx.close().catch(() => {});
          } catch {}
          resolve();
        }
      };

      source.onended = cleanup;
      // Safety timeout: if onended fails to trigger (mobile sleep / audio context pause), resolve unconditionally
      const maxDurationMs = Math.max(300, audioBuffer.duration * 1000 + 350);
      setTimeout(cleanup, maxDurationMs);
    });
  } catch (error) {
    console.error("Error playing audio:", error);
  }
}
